public class GlobalVariables
{
    public static string UserId;
    public static string RoomId = string.Empty;
    public static string Host;
    public static string FirstTurn;
    public static bool IsMyTurn;
    public static bool OpponentWantToRest;
    
    public const int MaxUsers = 2;
    public const int TurnTime = 30;
}