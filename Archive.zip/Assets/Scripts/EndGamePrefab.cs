using TMPro;
using UnityEngine;

public class EndGamePrefab : MonoBehaviour
{
    public TMP_Text title;

    public void SetWinner(string header)
    {
        title.text = header;
    }
}
