﻿using UnityEngine;
using System.Collections.Generic;

namespace BattleShips
{
    public class GridUtils : MonoBehaviour
    {
        // public static void AssignSpecialTiles(IGrid grid, int specialTileCount)
        // {
        //     List<Tile> allTiles = grid.GetAllTiles();
        //     System.Random random = new System.Random();
        //
        //     for (int i = 0; i < specialTileCount; i++)
        //     {
        //         if (allTiles.Count == 0)
        //         {
        //             Debug.LogWarning("No more tiles available to assign as special.");
        //             break;
        //         }
        //
        //         int randomIndex = random.Next(allTiles.Count);
        //         Tile randomTile = allTiles[randomIndex];
        //         randomTile.MarkAsSpecial();
        //         allTiles.RemoveAt(randomIndex);
        //     }
        // }
    }
}