﻿using System.Collections.Generic;
using UnityEngine;

namespace BattleShips
{
    public class LocalGridManager : MonoBehaviour, IGrid
    { 
        public Dictionary<Position, Tile> GridTiles { get; private set; }
        public GameManager GameManagerInstance { get; set; }

        public LocalGridManager(GameManager gameManager)
        {
            GameManagerInstance = gameManager;
        }
        
        private void Awake()
        {
            InitializeGrid();
        }

        public int NumRows { get; private set; }
        public int NumColumns { get; private set; }

        public void InitializeGrid()
        {
            GridTiles = new Dictionary<Position, Tile>();

            // Check if there are tiles under the VisualGridManager
            if (transform.childCount == 0)
            {
                Debug.LogError("No tiles found under VisualGridManager. Ensure that tiles are child objects of VisualGridManager.");
                return;
            }

            for (var i = 0; i < transform.childCount; i++)
            {
                var tileObject = transform.GetChild(i).gameObject;
                var row = i / 6; // Now safe as GameManagerInstance is assigned
                var col = i % 6;

                var tileComponent = tileObject.GetComponent<Tile>();
                if (tileComponent != null)
                {
                    var position = new Position(row, col);
                    tileComponent.Initialize(position);

                    if (!GridTiles.ContainsKey(position))
                    {
                        GridTiles.Add(position, tileComponent);
                    }
                    else
                    {
                        Debug.LogWarning($"Duplicate tile position detected at {position}");
                    }
                }
                else
                {
                    Debug.LogError($"Tile component not found on child GameObject: {tileObject.name}");
                }
            }
        }
        
        public bool TryGetTile(Position position, out Tile tile)
        {
            return GridTiles.TryGetValue(position, out tile);
        }

        public Dictionary<Position, Tile> GetAllTiles()
        {
            return new Dictionary<Position, Tile>(GridTiles);
        }

        // public void AssignSpecialTiles(int specialTileCount)
        // {
        //     var allTiles = GetAllTiles();
        //     var random = new System.Random();
        //
        //     for (var i = 0; i < specialTileCount; i++)
        //     {
        //         if (allTiles.Count == 0)
        //         {
        //             Debug.LogWarning("No more tiles available to assign as special.");
        //             break;
        //         }
        //
        //         var randomIndex = random.Next(allTiles.Count);
        //         var randomTile = allTiles[randomIndex];
        //         randomTile.MarkAsSpecial();
        //         allTiles.RemoveAt(randomIndex);
        //     }
        // }

        public bool CanPlaceShip(Position position, int size)
        {
            return true; //IsOccupied(position, size);
        }

        public void PlaceShip(Position position, Ship ship)
        {
            //shipPlacer.PlaceShip(position, ship.Size, ship);
        }
        
        public void ResetGrid()
        {
            foreach (var gridTile in GridTiles)
            {
                gridTile.Value.ResetTile();
            }
        }

        public void GenerateSpecialTiles(int amount)
        {
            var dictKeyList = new List<Position>(GridTiles.Keys);
            
            for (var i = 0; i < amount; i++)
            {
                var randIndex = Random.Range(0, dictKeyList.Count);
                var randomKey = dictKeyList[randIndex];

                if (GridTiles[randomKey].IsSpecialTile)
                {
                    i--;
                    continue;
                }
                
                GridTiles[randomKey].SetSpecialTile();
                
                Debug.Log("Random Value: " + randomKey);
            }
        }
    }
}