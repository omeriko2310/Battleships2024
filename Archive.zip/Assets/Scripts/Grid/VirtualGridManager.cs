﻿using System.Collections.Generic;
using UnityEngine;

namespace BattleShips
{
    public class VirtualGridManager : IGrid
    {
        public Dictionary<Position, Tile> GridTiles { get; private set; }
        public GameManager GameManagerInstance { get; set; }

        public int NumRows { get; private set; }
        public int NumColumns { get; private set; }

        public VirtualGridManager(GameManager gameManager)
        {
            GameManagerInstance = gameManager;
            NumRows = 6;
            NumColumns = 6;
        }

        public void InitializeGrid()
        {
            GridTiles = new Dictionary<Position, Tile>();

            for (int row = 0; row < NumRows; row++)
            {
                for (int col = 0; col < NumColumns; col++)
                {
                    var position = new Position(row, col);
                    var tileObject = new GameObject("Tile" + row + "," + col);
                    var tile = tileObject.AddComponent<Tile>();
                    
                    tile.Initialize(position);

                    GridTiles.Add(position, tile);
                }
            }
        }

        public bool TryGetTile(Position position, out Tile tile)
        {
            return GridTiles.TryGetValue(position, out tile);
        }

        public Dictionary<Position, Tile> GetAllTiles()
        {
            return new Dictionary<Position, Tile>(GridTiles);
        }

        public bool CanPlaceShip(Position startPosition, int shipSize)
        {
            if (startPosition.Column + shipSize > NumColumns)
                return false;

            for (int i = 0; i < shipSize; i++)
            {
                Position testPosition = new Position(startPosition.Row, startPosition.Column + i);
                if (GridTiles.TryGetValue(testPosition, out var tile) && tile.IsOccupied)
                    return false;
            }

            return true;
        }

        public void PlaceShip(Position startPosition, Ship ship)
        {
            // for (int i = 0; i < ship.Size; i++)
            // {
            //     Position position = new Position(startPosition.Row, startPosition.Column + i);
            //     if (GridTiles.TryGetValue(position, out var tile))
            //     {
            //         tile.Occupy(ship);
            //     }
            // }
        }
        
        public void ResetGrid()
        {
            foreach (var gridTile in GridTiles)
            {
                gridTile.Value.ResetTile();
            }
        }

        public void GenerateSpecialTiles(int amount)
        {
            var dictKeyList = new List<Position>(GridTiles.Keys);
            
            for (var i = 0; i < amount; i++)
            {
                var randIndex = Random.Range(0, dictKeyList.Count);
                var randomKey = dictKeyList[randIndex];

                if (GridTiles[randomKey].IsSpecialTile)
                {
                    i--;
                    continue;
                }
                
                GridTiles[randomKey].SetSpecialTile();
                
                Debug.Log("Random Value: " + GridTiles[randomKey]);
            }
        }
    }
}