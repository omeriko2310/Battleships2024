﻿using System;
using System.Collections.Generic;
using UnityEngine;

namespace BattleShips
{
    public interface IGrid
    {
        GameManager GameManagerInstance { get; set; }
        [SerializeField] Dictionary<Position, Tile> GridTiles { get; }
        Dictionary<Position, Tile> GetAllTiles();
        bool TryGetTile(Position position, out Tile tile);
        void InitializeGrid();
        bool CanPlaceShip(Position position, int size);
        void PlaceShip(Position position, Ship ship);
        int NumRows { get; }
        int NumColumns { get; }
        void ResetGrid();
        void GenerateSpecialTiles(int amount);
        // void AssignSpecialTiles(int specialTileCount);
    }
}