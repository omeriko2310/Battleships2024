using System;
using System.Collections;
using System.Collections.Generic;
using AssemblyCSharp;
using com.shephertz.app42.gaming.multiplayer.client;
using com.shephertz.app42.gaming.multiplayer.client.events;
using Newtonsoft.Json;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace BattleShips
{
    public class NetworkManager : MonoBehaviour
    {
        public static NetworkManager Instance { get; private set; }

        public TMP_Text connectionStatus;
        public TMP_Text currentRoomId;
        public TMP_Text userIdTMP;

        private const string APIKey = "954032240a8d5898bce2acfc912d541eebb0a72954ba0b61f74dc793001174bf";
        private const string SecretKey = "0dea4cfbbbbced3d359ebc875f0444df53da14ba2c3146c03f68681aeed29e26";
        private const string PasswordKey = "Password";
        private const string PasswordValue = "Shenkar";
        private const string EventName = "EventName";
        private const string EventData = "EventData";


        private Listener _myListener;
        private List<string> _roomIds;
        private Dictionary<string, object> _matchRoomData;
        private int _roomIndex = 0;

        public Action OnConnected;
        public Action OnMoveEnded;
        public Action<Dictionary<string, object>> FinishPlacing;
        public Action<Dictionary<string, object>> AttackReceived;
        public Action<Dictionary<string, object>> TurnPassed;
        public Action<Dictionary<string, object>> AttackResponse;
        public Action<Dictionary<string, object>> LoserResponse;
        
        private void OnEnable()
        {
            Listener.OnConnect += OnConnect;
            Listener.OnRoomsInRange += OnRoomsInRange;
            Listener.OnCreateRoom += OnCreateRoom;
            Listener.OnJoinRoom += OnJoinRoom;
            Listener.OnGetLiveRoomInfo += OnGetLiveRoomInfo;
            Listener.OnUserJoinRoom += OnUserJoinRoom;
            Listener.OnGameStarted += OnGameStarted;
            Listener.OnMoveCompleted += OnMoveCompleted;
        }

        private void OnDisable()
        {
            Listener.OnConnect -= OnConnect;
            Listener.OnRoomsInRange -= OnRoomsInRange;
            Listener.OnCreateRoom -= OnCreateRoom;
            Listener.OnJoinRoom -= OnJoinRoom;
            Listener.OnGetLiveRoomInfo -= OnGetLiveRoomInfo;
            Listener.OnUserJoinRoom -= OnUserJoinRoom;
            Listener.OnGameStarted -= OnGameStarted;
            Listener.OnMoveCompleted -= OnMoveCompleted;
        }

        private void Awake()
        {

            _myListener = new Listener();
            _matchRoomData = new Dictionary<string, object>();

            WarpClient.initialize(APIKey, SecretKey); //save my api and secret keys
            WarpClient.GetInstance().AddChatRequestListener(_myListener);
            WarpClient.GetInstance().AddConnectionRequestListener(_myListener);
            WarpClient.GetInstance().AddUpdateRequestListener(_myListener);
            WarpClient.GetInstance().AddLobbyRequestListener(_myListener);
            WarpClient.GetInstance().AddNotificationListener(_myListener);
            WarpClient.GetInstance().AddRoomRequestListener(_myListener);
            WarpClient.GetInstance().AddZoneRequestListener(_myListener);
            WarpClient.GetInstance().AddTurnBasedRoomRequestListener(_myListener);

            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }

            Instance = this;
            DontDestroyOnLoad(gameObject);
            DontDestroyOnLoad(WarpClient.GetInstance());
        }

        void Start()
        {
            _matchRoomData.Add(PasswordKey, PasswordValue);
            GlobalVariables.UserId = Guid.NewGuid().ToString();

            WarpClient.GetInstance().Connect(GlobalVariables.UserId);
            UpdateStatus("Connecting...");
        }

        private void OnConnect(bool isSuccess)
        {
            if (isSuccess)
            {
                UpdateStatus("Connected!");
                OnConnected.Invoke();
            }
            else
            {
                UpdateStatus("Failed to connect!");
            }
        }

        private void UpdateStatus(string status)
        {
            connectionStatus.text = status;
            Debug.Log("Server " + status);
        }

        public void ConnectToRoom()
        {
            WarpClient.GetInstance().GetRoomsInRange(1, 2);
            UpdateStatus("Searching for a room...");
        }

        #region Events

        private void OnRoomsInRange(bool isSuccess, MatchedRoomsEvent eventObj)
        {
            if (isSuccess)
            {
                UpdateStatus("Parsing rooms...");
                _roomIds = new List<string>();

                foreach (var roomData in eventObj.getRoomsData())
                {
                    _roomIds.Add(roomData.getId());
                }
            }
            else
            {
                UpdateStatus("Error fetching rooms in range");
            }

            _roomIndex = 0;
            DoRoomSearchLogic();
        }

        private void OnCreateRoom(bool isSuccess, string roomId)
        {
            if (isSuccess)
            {
                JoinRoomLogic(roomId, "Room was created! number: " + GlobalVariables.RoomId + " , waiting for opponent...");
            }
            else
            {
                UpdateStatus("Failed to create room!");
            }
        }

        private void OnJoinRoom(bool isSuccess, string roomId)
        {
            if (isSuccess)
            {
                UpdateStatus("Joined room id: " + roomId);
                userIdTMP.text = GlobalVariables.UserId;
                currentRoomId.text = "Room ID: " + roomId;
            }
            else
            {
                UpdateStatus("Failed to join room id: " + roomId);
            }
        }


        private void OnGetLiveRoomInfo(LiveRoomInfoEvent eventObj)
        {
            if (eventObj != null && eventObj.getProperties() != null)
            {
                Dictionary<string, object> properties = eventObj.getProperties();

                if (properties.ContainsKey(PasswordKey) &&
                    properties[PasswordKey].ToString() == _matchRoomData[PasswordKey].ToString())
                {
                    JoinRoomLogic(eventObj.getData().getId(),
                        "Received room info, joining room... " + GlobalVariables.RoomId);
                }
                else
                {
                    _roomIndex++;
                    DoRoomSearchLogic();
                }
            }
        }

        private void OnUserJoinRoom(RoomData eventObj, string userId)
        {
            if (eventObj.getRoomOwner() == GlobalVariables.UserId && GlobalVariables.UserId != userId)
            {
                UpdateStatus("Starting new game...");
                WarpClient.GetInstance().startGame();
            }
        }

        private void OnGameStarted(string host, string roomId, string firstTurn)
        {
            UpdateStatus("Game started, current turn: " + firstTurn);
            GlobalVariables.Host = host;
            GlobalVariables.FirstTurn = firstTurn;

            GlobalVariables.IsMyTurn = GlobalVariables.UserId == firstTurn;
            
            SceneManager.LoadScene("Game");
        }

        private void OnMoveCompleted(MoveEvent move)
        {
            UpdateStatus(move.getSender() + " Sent data");
            
            if (move.getSender() != GlobalVariables.UserId && move.getMoveData() != null)
            {
                Dictionary<string, object> moveEvent = JsonConvert.DeserializeObject<Dictionary<string, object>>(move.getMoveData());
                Dictionary<string, object> data = JsonConvert.DeserializeObject<Dictionary<string, object>>(moveEvent[EventData].ToString());
                
                switch (moveEvent[EventName])
                {
                    case NetworkEvents.FinishPlacing:
                        FinishPlacing.Invoke(data);
                        Debug.Log("Finished placing");
                        break;
                    case NetworkEvents.Attack:
                        AttackReceived.Invoke(data);
                        Debug.Log("Attack Received");
                        break;
                    case NetworkEvents.PassTurn:
                        TurnPassed.Invoke(data);
                        Debug.Log("Turn Passed received");
                        break;
                    case NetworkEvents.AttackResponse:
                        AttackResponse.Invoke(data);
                        Debug.Log("Response Received");
                        break;
                    case NetworkEvents.Lose:
                        LoserResponse.Invoke(data);
                        Debug.Log("Lose Received");
                        break;
                }
            }
            else if (move.getMoveData() == null)
                TurnPassed.Invoke(null);

            OnMoveEnded.Invoke();
            GlobalVariables.IsMyTurn = move.getNextTurn() == GlobalVariables.UserId;
        }

        #endregion


        private void DoRoomSearchLogic()
        {
            if (_roomIndex < _roomIds.Count)
            {
                WarpClient.GetInstance().GetLiveRoomInfo(_roomIds[_roomIndex]);
            }
            else
            {
                UpdateStatus("Creating new room...");
                WarpClient.GetInstance().CreateTurnRoom("Omer Room", GlobalVariables.UserId, GlobalVariables.MaxUsers, _matchRoomData, GlobalVariables.TurnTime);
            }
        }

        private void JoinRoomLogic(string roomId, string status)
        {
            GlobalVariables.RoomId = roomId;
            UpdateStatus(status);
            WarpClient.GetInstance().JoinRoom(GlobalVariables.RoomId);
            WarpClient.GetInstance().SubscribeRoom(GlobalVariables.RoomId);
        }

        public void SendMove(string eventName, Dictionary<string, object> data)
        {
            Dictionary<string, object> toSend = new Dictionary<string, object>
            {
                { EventName, eventName },
                { EventData, data },
            };
                
            string json = JsonConvert.SerializeObject(toSend);
            
            StartCoroutine(SendData(eventName, json));
        }

        private IEnumerator SendData(string eventName, string json)
        {
            if (json == null) yield break;
            
            if (eventName == NetworkEvents.FinishPlacing)
            {
                yield return new WaitUntil(() => GlobalVariables.IsMyTurn);
            }
            
            Debug.Log("Sending: " + json);
            WarpClient.GetInstance().sendMove(json);
        }
    }
}

public class NetworkEvents
{
    //Events name
    public const string FinishPlacing = "FinishPlacing";
    public const string PassTurn = "PassTurn";
    public const string Attack = "Attack";
    public const string AttackResponse = "AttackResponse";
    public const string Lose = "Win";
    
    //Data variables
    public const string PlayerReady = "PlayerReady";
    public const string TilePosition = "TilePosition";
    public const string TileDTO = "TileDTO";
    public const string DidPlayWon = "DidPlayerWon";
}