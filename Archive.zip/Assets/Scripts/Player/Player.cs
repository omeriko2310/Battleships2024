﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BattleShips
{
    public abstract class Player
    {
        public string Name;
        public IGrid GridManager { get; protected set; }
        public GameManager GameManagerInstance { get; }
        public ShipsManagerBase ShipsManagerInstance { get; }
        public bool IsPlayerReady { get; set; }
        private int SpecialTileTurnCounter { get; set; }
        public bool CanPlayTurn => SpecialTileTurnCounter == 0;

        public abstract void Initialize();

        public virtual IEnumerator PerformAttack(Player opponent, Position gridPosition)
        {
            Tile hitTile = opponent.ReceiveAttack(gridPosition);

            if (hitTile != null)
            {
                EvaluateSpecialTile(hitTile);
                MarkAttackedTile(gridPosition, hitTile.IsOccupied);
            }
            
            yield return null;
        }

        public virtual void MarkAttackedTile(Position gridPosition, bool hitTileIsOccupied) { }

        public virtual Tile ReceiveAttack(Position position)
        {
            if (GridManager.TryGetTile(position, out var tile))
            {
                if (tile.IsHit)
                {
                    Debug.Log($"Tile {position} has already been attacked.");
                    return null;
                }

                tile.MarkAsHit();

                if (tile.IsOccupied)
                {
                    var ship = tile.OccupyingShip;
                    ship?.RegisterHit(tile);
                    
                    Debug.Log($"Opponent hit {Name}'s ship at {position.Row}, {position.Column}.!");

                    if (ship != null && ship.IsSunk)
                    {
                        Debug.Log($"{Name}'s ship of size {ship.Size} has been sunk!");
                    }
                }

                Debug.Log($"Opponent missed {Name}'s ship at {position}.");
            }
            else
            {
                Debug.LogError($"Invalid tile at position: {position}");
            }

            return tile;
        }
        
        protected Player(GameManager gameManager, ShipsManagerBase shipsManager, IGrid gridManager)
        {
            GameManagerInstance = gameManager;
            ShipsManagerInstance = shipsManager;
            GridManager = gridManager;
        }

        public List<Ship> GetShips()
        {
            return ShipsManagerInstance.PlacedShips;
        }

        public bool AreAllShipsSunk()
        {
            var temp = ShipsManagerInstance.PlacedShips.TrueForAll(ship => ship.IsSunk);
            Debug.Log(temp + " something broken");
            return ShipsManagerInstance.PlacedShips.TrueForAll(ship => ship.IsSunk);
        }
        
        
        public bool TryGetTile(Position position, out Tile tile)
        {
            return GridManager.TryGetTile(position, out tile);
        }

        public IGrid TryGetGrid()
        {
            return GridManager;
        }

        public void GenerateSpecialTiles(int amount)
        {
            GridManager.GenerateSpecialTiles(amount);
        }

        public void OnResetButtonClicked()
        {
            GridManager.ResetGrid();
        }

        public virtual void StartPlacementPhase() { }
        
        public bool CheckTileCondition()
        {
            var aliveTiles = GridManager.GridTiles.Any(pair => pair.Value.IsOccupied && !pair.Value.IsHit);
            return aliveTiles;
        }

        public virtual IEnumerator FetchAttackPosition(Action<Position> action)
        {
            yield return null;
        }

        private void EvaluateSpecialTile(Tile tile)
        {
            if (!tile || !tile.IsSpecialTile) return;

            SpecialTileHit();
        }

        public void SpecialTileHit()
        {
            SpecialTileTurnCounter++;
            
            Debug.Log($"{Name} hit Special Tile!");
        }

        public void EvaluatePlayerPassingTurn()
        {
            SpecialTileTurnCounter--;
        }
        
    }
}