﻿using System.Collections;
using System.Collections.Generic;
using com.shephertz.app42.gaming.multiplayer.client;
using UnityEngine;

namespace BattleShips
{
    public class RemotePlayer : Player
    {
        public RemotePlayer(GameManager gameManager, ShipsManagerBase shipsManager, IGrid gridManager) : base(gameManager, shipsManager, gridManager)
        {
            Name = "RemotePlayer";
            GridManager = gridManager;
        }

        public override void Initialize()
        {
            GridManager.InitializeGrid();
        }

        public override Tile ReceiveAttack(Position position)
        {
            NetworkManager.Instance.SendMove(NetworkEvents.Attack, new Dictionary<string, object>
            {
                { NetworkEvents.TilePosition, position }
            });
            
            return null;
        }

        public override IEnumerator PerformAttack(Player opponent, Position gridPosition)
        {
            var attackPosition = GetAttackPositionFromNetwork();
            
            opponent.ReceiveAttack(attackPosition);
            
            Debug.Log($"RemotePlayer attacks position {gridPosition?.Row}, {gridPosition?.Column}");
            
            yield return null;
        }

        private Position GetAttackPositionFromNetwork()
        {
            // Implement network communication to receive the attack position
            // Placeholder implementation
            return new Position(0, 0);
        }
        
        public override void StartPlacementPhase()
        {
            IsPlayerReady = true;
        }
    }
}