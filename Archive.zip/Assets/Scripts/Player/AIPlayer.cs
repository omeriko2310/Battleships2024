﻿using System;
using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using Random = UnityEngine.Random;

namespace BattleShips
{
    public class AIPlayer : Player
    {
        public AIPlayer(GameManager gameManager, VirtualShipsManager shipsManager, VirtualGridManager gridManager) : base(gameManager, shipsManager, gridManager)
        {
            Name = "AIPlayer";
            GridManager = gridManager;
        }

        public override void Initialize()
        {
            GridManager.InitializeGrid();
        }

        public override void StartPlacementPhase()
        {
            PlaceShipsRandomlyOnGrid();

            IsPlayerReady = true;
        }

        public override IEnumerator FetchAttackPosition(Action<Position> action)
        {
            var row = Random.Range(0, 6);
            var col = Random.Range(0, 6);

            action.Invoke(new Position(row, col));
            
            yield break;
        }

        public override IEnumerator PerformAttack(Player opponent, Position gridPosition)
        {
            yield return new WaitForSeconds(1f);

            if (!CanPlayTurn)
            {
                EvaluatePlayerPassingTurn();
                yield break;
            }

            yield return base.PerformAttack(opponent, gridPosition);
            
            Debug.Log($"AI attacks position {gridPosition.Row}, {gridPosition.Column}");
        }

        private void PlaceShipsRandomlyOnGrid()
        {
            var shipSizes = new List<int> { 4, 3, 2, 1 };
            var ships = new List<Ship>();

            // Create ships and attach them to GameObjects
            foreach (var size in shipSizes)
            {
                var shipObject = new GameObject("Ship" + size);
                var ship = shipObject.AddComponent<Ship>();
                ship.Size = size;
                ships.Add(ship);
            }

            foreach (var ship in ships)
            {
                var shipPlaced = false;
                var attempts = 0;

                while (!shipPlaced && attempts < 100)
                {
                    attempts++;
                    var row = Random.Range(0, 6);
                    var col = Random.Range(0, 6);

                    var startPosition = new Position(row, col);
                    
                    var tiles = ShipPlacer.PlaceShip(startPosition, ship, GridManager);
                    
                    if (tiles != null)
                    {
                        shipPlaced = true;
                    }
                }

                if (!shipPlaced)
                {
                    Debug.LogError($"AI failed to place ship of size {ship} after {attempts} attempts.");
                }
            }
            
            PrintShipsGridToConsole(ships);
            
            Debug.Log($"AI finished placing ships.");
        }

        private void PrintShipsGridToConsole(List<Ship> ships)
        {
            foreach (var ship in ships)
            {
                foreach (var shipTile in ship.Tiles)
                {
                    Debug.Log(ship.name + ": " + shipTile.GridPosition.Row + "," + shipTile.GridPosition.Column);
                }
            }
        }
    }
}