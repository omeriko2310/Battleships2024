﻿using System;
using System.Collections;
using JetBrains.Annotations;
using UnityEngine;

namespace BattleShips
{
    public class LocalPlayer : Player
    {
        public LocalPlayer(GameManager gameManager, ShipsManagerBase shipsManager, IGrid gridManager) : base(gameManager, shipsManager, gridManager)
        {
            Name = "LocalPlayer";
        }

        public override void Initialize()
        {
            ShipsManagerInstance.Initialize();
        }

        [CanBeNull]
        public override IEnumerator PerformAttack(Player opponent, Position gridPosition)
        {
            yield return base.PerformAttack(opponent, gridPosition);
            
            Debug.Log($"LocalPlayer attacks position {gridPosition.Row}, {gridPosition.Column}");
            
            yield return null;
        }

        public override void MarkAttackedTile(Position gridPosition, bool isOccupied)
        {
            if (GridManager.TryGetTile(gridPosition, out var tile))
            {
                tile.MarkAsAttacked(isOccupied);
            }
        }
    }
}