﻿using UnityEngine;
using TMPro;

namespace BattleShips
{
    public class AttackInputManager : MonoBehaviour
    {
        public TMP_InputField attackInputField;

        private void Start()
        {
            attackInputField.interactable = false;
        }

        public void OnPlayerTurn()
        {
            attackInputField.interactable = true;
        }

        public void OnResetButtonClicked()
        {
            attackInputField.interactable = false;
        }
        
        public Position OnAttackButtonClicked()
        {
            attackInputField.interactable = false;
            
            var coordinate = attackInputField.text.ToUpper().Trim();

            if (IsValidCoordinate(coordinate))
            {
                var position = Position.FromString(coordinate);

                attackInputField.text = ""; // Clear the input field after attack
                
                return position;
            }
            
            Debug.LogError($"Invalid coordinate: {coordinate}");
            
            return null;
        }

        private bool IsValidCoordinate(string input)
        {
            if (string.IsNullOrEmpty(input) || input.Length < 2) return false;

            var column = input[0];
            var rowPart = input.Substring(1);

            if (column < 'A' || column > 'F') return false;

            if (!int.TryParse(rowPart, out var row)) return false;

            return row >= 1 && row <= 6;
        }
    }
}