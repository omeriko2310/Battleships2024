using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class EndGamePopup : MonoBehaviour
{
    public TMP_Text title;
    public Button resetButton;
    
    public void SetWinner(string header)
    {
        title.text = header;
        resetButton.interactable = true;
    }

    public void OnResetButtonClicked()
    {
        title.text = "Awaiting opponent response...";
        resetButton.interactable = false;
    }
}
