using System;

namespace BattleShips
{
    [Serializable]
    public class TileDTO
    {
        public int Row { get; set; }
        public int Column { get; set; }
        public bool IsOccupied { get; set; }
        public bool IsSpecialTile { get; set; }
        public bool IsHit { get; set; }
        
        public ShipDTO OccupyingShip { get; set; }  // Include ShipDTO here
    }
}