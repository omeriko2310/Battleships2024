using System.Collections.Generic;

namespace BattleShips
{
    public static class DataConverterUtility
    {
        public static Dictionary<Position, TileDTO> ConvertToDTO(Dictionary<Position, Tile> tileDict)
        {
            var dtoDict = new Dictionary<Position, TileDTO>();
            foreach (var kvp in tileDict)
            {
                Position pos = kvp.Key;
                Tile tile = kvp.Value;

                var tileDto = new TileDTO
                {
                    Row = pos.Row,
                    Column = pos.Column,
                    IsOccupied = tile.IsOccupied,
                    IsSpecialTile = tile.IsSpecialTile,
                    IsHit = tile.IsHit
                };

                // If a ship occupies this tile, convert ship data
                if(tile.IsOccupied && tile.OccupyingShip != null)
                {
                    var ship = tile.OccupyingShip;
                    tileDto.OccupyingShip = new ShipDTO
                    {
                        Size = ship.Size,
                        Placed = ship.Placed,
                        IsSunk = ship.IsSunk
                        // Copy additional properties if needed
                    };
                }

                dtoDict[pos] = tileDto;
            }
            return dtoDict;
        }
    }
}