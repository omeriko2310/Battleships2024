using System;

namespace BattleShips
{
    [Serializable]
    public class ShipDTO
    {
        public int Size { get; set; }
        public bool Placed { get; set; }
        public bool IsSunk { get; set; }
        
    }
}