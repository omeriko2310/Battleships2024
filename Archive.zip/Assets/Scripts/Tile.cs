using Newtonsoft.Json;
using UnityEngine;

namespace BattleShips
{
    public class Tile : MonoBehaviour
    {
        public bool IsOccupied { get; private set; }
        public Ship OccupyingShip { get; private set; }
        public Position GridPosition { get; private set; }
        public bool IsSpecialTile { get; private set; }
        public bool IsHit { get; set; }
        
        [JsonIgnore] private TileAttackedIndication _tileAttackedIndication;
        [JsonIgnore] private SpriteRenderer _spriteRenderer;
        [JsonIgnore] private GameManager _gameManager;

        void Awake()
        {
            _spriteRenderer = GetComponent<SpriteRenderer>();
            _tileAttackedIndication = GetComponentInChildren<TileAttackedIndication>();
        }

        private void Start()
        {
            _gameManager = FindObjectOfType<GameManager>();

            IsHit = false;
        }

        public void Initialize(Position position)
        {
            GridPosition = position;
        }

        public void Occupy(Ship ship)
        {
            IsOccupied = true;
            OccupyingShip = ship;
        }
        
        // public void Clear()
        // {
        //     IsOccupied = false;
        //     OccupyingShip = null;
        //     HighlightTile(false);
        // }

        private void HighlightTile(Color color)
        {
            if (_spriteRenderer != null)
            {
                _spriteRenderer.color = color;
            }
        }


        private void HighlightTile(bool isSelected)
        {
            _spriteRenderer.color = isSelected ? Color.green : Color.white;
        }

        public void MarkAsHit()
        {
            if (IsHit)
                return; // Already hit

            IsHit = true;

            if (IsOccupied)
            {
                OccupyingShip.RegisterHit(this);
                HighlightTile(Color.red);
            }
            else
            {
                HighlightTile(Color.blue);
            }
        }

        void OnMouseDown()
        {
            // if (IsSpecialTile)
            // {
            //     Debug.Log($"Tile {GridPosition} is a special tile! Turn lost.");
            //     return;
            // }

            if (!IsHit)
            {
                _gameManager.OnTileClicked(GridPosition);
            }
        }

        public void ResetTile()
        {
            IsOccupied = false;
            IsSpecialTile = false;
            IsHit = false;
        }

        public void SetSpecialTile()
        {
            IsSpecialTile = true;
        }

        public void MarkAsAttacked(bool didHit)
        {
            _tileAttackedIndication.MarkHitOrMissStatus(didHit);
        }

        public void UpdateData(TileDTO tileDto)
        {
            
        }
    }
}