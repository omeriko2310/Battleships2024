using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SliderValueUpdater : MonoBehaviour
{
    public Slider slider;
    public TextMeshProUGUI valueText;
    public string prefix = "";

    void Start()
    {
        slider.onValueChanged.AddListener(UpdateValueText);
        UpdateValueText(slider.value);
    }

    void UpdateValueText(float value)
    {
        valueText.text = prefix + value.ToString("0");
    }
}
