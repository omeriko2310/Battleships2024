using System;
using UnityEngine;

public class TileAttackedIndication : MonoBehaviour
{
    [SerializeField] private Sprite hitMark;
    [SerializeField] private Sprite missMark;

    private SpriteRenderer _spriteRenderer;

    void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        _spriteRenderer.enabled = false;
    }

    public void MarkHitOrMissStatus(bool didHit)
    {
        if (_spriteRenderer.enabled)
        {
            return;
        }
        
        _spriteRenderer.enabled = true;
        
        if (didHit)
        {
            MarkAsHit();
        }
        else
        {
            MarkAsMiss();
        }
    }

    private void MarkAsHit()
    {
        _spriteRenderer.sprite = hitMark;
    }

    private void MarkAsMiss()
    {
        _spriteRenderer.sprite = missMark;
    }
    
}
