using UnityEngine;
using UnityEngine.UI;

namespace BattleShips
{
    namespace Multiplayer
    {
        public class MultiplayerUiManager : MonoBehaviour
        {
            public Button playButton;
            public Button backButton;
            public Button optionsButton;

            private NetworkManager _networkManager;

            private void Awake()
            {
                playButton.interactable = false;
            }

            private void Start()
            {
                _networkManager = GameObject.FindWithTag("Network").GetComponent<NetworkManager>();
                _networkManager.OnConnected += OnConnected;
            }

            private void OnConnected()
            {
                playButton.interactable = true;
            }

            public void OnPlayButtonClicked()
            {
                playButton.interactable = false;
                _networkManager.ConnectToRoom();
            }
        }
    }
}