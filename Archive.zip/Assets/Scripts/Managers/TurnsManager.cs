﻿using System;
using System.Collections;
using System.Collections.Generic;
using com.shephertz.app42.gaming.multiplayer.client;
using Newtonsoft.Json;
using UnityEngine;
using Random = UnityEngine.Random;

namespace BattleShips
{
    public class TurnsManager
    {
        private const int NumOfSpecialTiles = 5;
        
        private readonly GameManager _gameManager;
        private LocalPlayer _localPlayer;
        private Player _opponentPlayer;
        private Player _currentPlayer;
        private bool _isLocalGame;

        public bool IsLocalPlayerTurn => _currentPlayer == _localPlayer;
        // public bool CurrentPlayerNeedToPassTurn => _currentPlayer.CanPlayTurn;

        public Action<LocalPlayer> LocalPlayerTurn;
        public Action GameSetupFinished;

        public TurnsManager(GameManager gameManager)
        {
            var localPlayerShips = new LocalShipsManager(null);
            var localPlayerGrid = gameManager.localGrid;
            
            _gameManager = gameManager;
            _localPlayer = new LocalPlayer(_gameManager, localPlayerShips, localPlayerGrid);
            _currentPlayer = _localPlayer;
        }
        
        public void Initialize(bool isLocalGame)
        {
            SetGameType(isLocalGame);

            _isLocalGame = isLocalGame;
            _localPlayer.Initialize();
            _opponentPlayer.Initialize();
        }
        
        public IEnumerator GameSetup()
        {
            StartPlacementPhase();
            
            yield return WaitForPlayersReadiness();

            if (_isLocalGame)
            {
                ChooseStartingPlayer();
            }
            
            GameSetupFinished.Invoke();
        }

        public void StartGame()
        {
            PlayNextMove();
        }
        
        private void CheckWinOrLoseCondition()
        {
            if (!_localPlayer.CheckTileCondition())
            {
                Debug.Log("local player lost");
                _gameManager.GameOver(false);
            }

            if (!_opponentPlayer.CheckTileCondition())
            {
                Debug.Log("opponent player lost");
                _gameManager.GameOver(true);
            }
        }

        public void NextTurn()
        {
            CheckWinOrLoseCondition();

            SetCurrentPlayer();

            PlayNextMove();
        }

        private void SetCurrentPlayer()
        {
            if (_isLocalGame)
            {
                _currentPlayer = IsLocalPlayerTurn ? _opponentPlayer : _localPlayer;
            }
            else
            {
                _currentPlayer = GlobalVariables.IsMyTurn ? _localPlayer : _opponentPlayer;
            }
        }

        private void PlayNextMove()
        {
            if (IsLocalPlayerTurn)
            {
                LocalPlayerTurn.Invoke(_localPlayer);
            }
            else
            {
                _gameManager.StartCoroutine(EvaluateOpponentAttack());
            }
        }

        private IEnumerator EvaluateOpponentAttack()
        {
            Position position = null;
            
            yield return _opponentPlayer.FetchAttackPosition(pos =>
            {
                position = pos;
            });
            
            yield return _opponentPlayer.PerformAttack(_localPlayer, position);
            
            NextTurn();
        }

        private void ChooseStartingPlayer()
        {
            var random = Random.Range(0, 1);
            _currentPlayer = random == 0 ? _localPlayer : _opponentPlayer;
            
            Debug.Log($"First player to play: {_currentPlayer.Name}");
        }

        private void SetGameType(bool isLocalGame)
        {
            if (isLocalGame)
            {
                _opponentPlayer = new AIPlayer(_gameManager, new VirtualShipsManager(_gameManager), new VirtualGridManager(_gameManager));
            }
            else
            {
                _opponentPlayer = new RemotePlayer(_gameManager, new VirtualShipsManager(_gameManager), new VirtualGridManager(_gameManager));
            }
            
        }

        private void StartPlacementPhase()
        {
            _opponentPlayer.StartPlacementPhase();
        }

        private IEnumerator WaitForPlayersReadiness()
        {
            yield return new WaitUntil( () => _localPlayer.IsPlayerReady );
            Debug.Log("Local Player Ready");
            yield return new WaitUntil( () => _opponentPlayer.IsPlayerReady );
            Debug.Log("Opponent Player Ready");
        }

        public void LocalPlayerIsReady()
        {
            if (!_isLocalGame)
            {
                // Dictionary<Position, Tile> allTiles = _localPlayer.GridManager.GetAllTiles();
                // Dictionary<Position, TileDTO> tileDtoDict = DataConverterUtility.ConvertToDTO(allTiles);
                // Dictionary<Position, TileDTO> toSend = new Dictionary<Position, TileDTO>(tileDtoDict);
                // var settings = new JsonSerializerSettings
                // {
                //     ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                // };
                //
                // string json = JsonConvert.SerializeObject(toSend, settings);
                //
                // Debug.Log(json);
                
                NetworkManager.Instance.SendMove(NetworkEvents.FinishPlacing, new Dictionary<string, object>
                {
                    { NetworkEvents.PlayerReady , true }, 
                });
                
                Debug.Log("FinishedPlacing");
            }
            
            _localPlayer.IsPlayerReady = true;
        }

        public void ProcessPlayerAttack(Position position)
        {
            if (!IsLocalPlayerTurn)
            {
                Debug.LogWarning("It's not the local player's turn.");
                return;
            }

            // Local player performs attack
            // _gameManager.GetLocalPlayer().PerformAttack(_gameManager.GetOpponentPlayer());
            //
            // if (_gameManager.GetOpponentPlayer().AreAllShipsSunk())
            // {
            //     Debug.Log("Local player wins!");
            //     _gameManager.GameOver(true);
            // }
            // else
            // {
            //     _isLocalPlayerTurn = false;
            //     StartCoroutine(ProcessOpponentTurn());
            // }
        }

        // private IEnumerator ProcessOpponentTurn()
        // {
        //     yield return _gameManager.GetOpponentPlayer().ProcessTurnAsync(_gameManager.GetLocalPlayer());
        //     
        //     if (_gameManager.GetLocalPlayer().AreAllShipsSunk())
        //     {
        //         Debug.Log("Opponent wins!");
        //         _gameManager.GameOver(false);
        //     }
        //     else
        //     {
        //         _isLocalPlayerTurn = true;
        //         Debug.Log("Local player's turn.");
        //     }
        // }
        
        public bool TryGetTile(Position position, out Tile tile)
        {
            return _currentPlayer.TryGetTile(position, out tile);
        }

        public IGrid TryGetGrid()
        {
            return _currentPlayer.TryGetGrid();
        }

        public void OnAllShipsPlaced()
        {
            _currentPlayer.GenerateSpecialTiles(NumOfSpecialTiles);
            
            //AI - check remote player
            _opponentPlayer.GenerateSpecialTiles(NumOfSpecialTiles);
        }

        public void OnResetButtonClicked()
        {
            
        }

        public void PreformAttack(Position gridPosition)
        {
            _gameManager.StartCoroutine(_currentPlayer.PerformAttack(_opponentPlayer, gridPosition));
        }

        public void TimeEnded()
        {
            // NextTurn();
        }
        
        #region Network

        public void NetworkTurnPassed(Dictionary<string, object> data)
        {
            NextTurn();
        }

        public void NetworkAttackReceived(Dictionary<string, object> data)
        {
            Position tilePosition = JsonConvert.DeserializeObject<Position>(data[NetworkEvents.TilePosition].ToString());
            Debug.Log("Received Position: " + tilePosition.Row + ", " + tilePosition.Column);
            
            Tile tile = _localPlayer.ReceiveAttack(tilePosition);
            TileDTO tileDto = new TileDTO()
            {
                IsOccupied = tile.IsOccupied,
                IsSpecialTile = tile.IsSpecialTile,
                IsHit = tile.IsHit,
            };
            
            NetworkManager.Instance.SendMove(NetworkEvents.AttackResponse, new Dictionary<string, object>
            {
                { NetworkEvents.TilePosition, tilePosition },
                { NetworkEvents.TileDTO, tileDto },
            });
        }

        public void NetworkFinishPlacing(Dictionary<string, object> data)
        {
            _opponentPlayer.StartPlacementPhase();
        }
        
        public void AttackResponse(Dictionary<string, object> data)
        {
            Position tilePosition = JsonConvert.DeserializeObject<Position>(data[NetworkEvents.TilePosition].ToString());
            TileDTO tileDto = JsonConvert.DeserializeObject<TileDTO>(data[NetworkEvents.TileDTO].ToString());

            if (tileDto != null && tileDto.IsSpecialTile)
            {
                _localPlayer.SpecialTileHit();
                Debug.Log("Special Tile Hit");
            }

            if (tileDto != null)
            {
                _localPlayer.MarkAttackedTile(tilePosition, tileDto.IsOccupied);
                Debug.Log("Hit an Occupied Tile");
            }
            
            NetworkManager.Instance.SendMove(NetworkEvents.PassTurn, new Dictionary<string, object>());
        }

        #endregion
    }
}