using System.Collections.Generic;
using Newtonsoft.Json;
using UnityEngine;

namespace BattleShips
{
    public class GameManager : MonoBehaviour
    {
        public UiManager uiManager;
        public LocalGridManager localGrid;
        public NetworkManager networkManager;
        
        private TurnsManager _turnsManager;
        private ShipPlacer _shipPlacer;
        
        public bool IsGameReady { get; private set; }
        public bool IsGameOver { get; private set; }
        public bool IsLocalGame { get; private set; }
        public bool IsGameStarted { get; private set; }
        public float StartTimer { get; private set; }
        
        private void Awake()
        {
            networkManager = GameObject.FindGameObjectWithTag("Network")?.GetComponent<NetworkManager>();
            
            if (networkManager == null)
            {
                IsLocalGame = true;
            }
        }
        
        void Start()
        {
            InitializeGame();
            SetEvents();
            GameSetup();
        }

        private void Update()
        {
            int currentTime = GlobalVariables.TurnTime - (int)(Time.time - StartTimer);
            
            if (networkManager != null && !IsGameOver && IsGameStarted)
            {
                uiManager?.UpdateTimer(currentTime);
            }
            else if (IsLocalGame && IsGameStarted)
            {
                uiManager?.UpdateTimer(currentTime);
            }

            if (currentTime <= 0 && IsGameStarted)
            {
                OnTimeIsUp();
            }
        }

        private void OnTimeIsUp()
        {
            _turnsManager.OnTimeIsUp();
        }

        private void InitializeGame()
        {
            IsGameOver = false;
            _turnsManager = new TurnsManager(this);
            _shipPlacer = new ShipPlacer(this);

            _turnsManager.Initialize(IsLocalGame);
        }
        
        private void SetEvents()
        {
            if (networkManager != null)
            {
                networkManager.FinishPlacing -= NetworkFinishPlacing;
                networkManager.FinishPlacing += NetworkFinishPlacing;

                networkManager.AttackReceived -= NetworkAttackReceived;
                networkManager.AttackReceived += NetworkAttackReceived;

                networkManager.TurnPassed -= NetworkTurnPassed;
                networkManager.TurnPassed += NetworkTurnPassed;

                networkManager.AttackResponse -= AttackResponse;
                networkManager.AttackResponse += AttackResponse;

                networkManager.LoserResponse -= LoserResponse;
                networkManager.LoserResponse += LoserResponse;

                networkManager.OnMoveEnded -= ResetTimer;
                networkManager.OnMoveEnded += ResetTimer;

                networkManager.ResetResponse -= ResetResponse;
                networkManager.ResetResponse += ResetResponse;
            }

            uiManager.ReadyButtonClicked -= OnReadyButtonClicked;
            uiManager.ReadyButtonClicked += OnReadyButtonClicked;

            uiManager.AttackButtonClicked -= OnAttackButtonClicked;
            uiManager.AttackButtonClicked += OnAttackButtonClicked;

            uiManager.ResetButtonClicked -= OnResetButtonClicked;
            uiManager.ResetButtonClicked += OnResetButtonClicked;

            uiManager.ResetPlacingClicked -= ResetPlacingClicked;
            uiManager.ResetPlacingClicked += ResetPlacingClicked;

            _shipPlacer.AllShipsPlaced -= OnAllShipsPlaced;
            _shipPlacer.AllShipsPlaced += OnAllShipsPlaced;

            _turnsManager.LocalPlayerTurn -= OnPlayerTurn;
            _turnsManager.LocalPlayerTurn += OnPlayerTurn;

            _turnsManager.GameSetupFinished -= OnGameSetupFinished;
            _turnsManager.GameSetupFinished += OnGameSetupFinished;

            _turnsManager.OnPlayNextMove -= ResetTimer;
            _turnsManager.OnPlayNextMove += ResetTimer;

        }

        private void ResetResponse(Dictionary<string, object> data)
        {
            GlobalVariables.OpponentWantToRest = (bool)data[NetworkEvents.DoPlayerWantToRestart];

            TryToResetGame();
        }

        private void TryToResetGame()
        {
            if (GlobalVariables.OpponentWantToRest && uiManager.ResetClicked)
            {
                ResetGame();
            }
        }

        private void LoserResponse(Dictionary<string, object> data)
        {
            bool didWin = (bool)data[NetworkEvents.DidPlayWon];
            
            uiManager.GameOver(true);
        }

        private void OnGameSetupFinished()
        {
            IsGameStarted = true;
            StartGame();
        }

        private void StartGame()
        {
            _turnsManager.StartGame();
        }

        private void OnPlayerTurn(LocalPlayer localPlayer)
        {
            if (localPlayer.CanPlayTurn)
            {
                uiManager.OnPlayerTurn();
            }
            else
            {
                localPlayer.EvaluatePlayerPassingTurn();
                _turnsManager.NextTurn();
            }
        }

        public bool CanPlaceShip()
        {
            return true;
        }

        private void OnAllShipsPlaced()
        {
            uiManager.OnAllShipsPlaced();
            _turnsManager.OnAllShipsPlaced();
        }

        private void OnReadyButtonClicked()
        {
            IsGameReady = true;
            _turnsManager.LocalPlayerIsReady();
        }

        public void GameOver(bool playerWon)
        {
            if (!IsLocalGame)
            {
                NetworkManager.Instance.SendMove(NetworkEvents.Lose, new Dictionary<string, object>()
                {
                    {NetworkEvents.DidPlayWon, playerWon}
                });
            }
            
            uiManager.GameOver(playerWon);
            IsGameStarted = false;
            IsGameReady = false;
        }

        private void GameSetup()
        {
            StartCoroutine(_turnsManager.GameSetup());
        }

        public bool TryGetTile(Position position, out Tile tile)
        {
           return _turnsManager.TryGetTile(position, out tile);
        }

        public IGrid TryGetGrid()
        {
            return _turnsManager.TryGetGrid();
        }

        public void OnTileClicked(Position gridPosition)
        {
            if (IsGameReady)
            {
                Debug.Log($"Attacking tile position: {gridPosition}");
                OnAttackButtonClicked(gridPosition);
            }
            else
            {
                _shipPlacer.OnTileClicked(gridPosition);
            }
        }

        public void OnShipClicked(Ship ship)
        {
            _shipPlacer.OnShipClicked(ship);
        }

        private void OnAttackButtonClicked(Position gridPosition)
        {
            if (!_turnsManager.IsLocalPlayerTurn) return;
            
            _turnsManager.PreformAttack(gridPosition);
            _turnsManager.NextTurn();
        }

        private void OnResetButtonClicked()
        {
            if (IsLocalGame)
            {
                ResetGame();
            }
            else
            {
                NetworkManager.Instance.SendMove(NetworkEvents.Reset, new Dictionary<string, object>()
                {
                    {NetworkEvents.DoPlayerWantToRestart, true}
                });

                TryToResetGame();
            }
        }

        private void ResetGame()
        {
            uiManager.ResetGame();
            ResetPlacingClicked();
            InitializeGame();
            SetEvents();
            GameSetup();
        }

        private void ResetPlacingClicked()
        {
            _shipPlacer.ResetShipsPositions();
            _turnsManager.OnResetButtonClicked();
        }

        #region Network

        private void NetworkTurnPassed(Dictionary<string, object> data)
        {
            _turnsManager.NetworkTurnPassed(data);
        }

        private void NetworkAttackReceived(Dictionary<string, object> data)
        {
            _turnsManager.NetworkAttackReceived(data);
        }

        private void NetworkFinishPlacing(Dictionary<string, object> data)
        {
            _turnsManager.NetworkFinishPlacing(data);
            
            if (GlobalVariables.FirstTurn != GlobalVariables.UserId && IsGameStarted && !IsLocalGame)
            {
                networkManager.SendMove(NetworkEvents.PassTurn , new Dictionary<string, object>());
            }
        }
        
        private void AttackResponse(Dictionary<string, object> data)
        {
            _turnsManager.AttackResponse(data);
        }
        
        private void ResetTimer()
        {
            if (IsGameStarted)
            {
                StartTimer = Time.time;
            }
        }

        #endregion
    }
}