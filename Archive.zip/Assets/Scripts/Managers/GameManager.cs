using System.Collections.Generic;
using UnityEngine;

namespace BattleShips
{
    public class GameManager : MonoBehaviour
    {
        public UiManager uiManager;
        public LocalGridManager localGrid;
        public NetworkManager networkManager;
        
        private TurnsManager _turnsManager;
        private ShipPlacer _shipPlacer;
        
        public bool IsGameOver { get; private set; }
        public bool IsLocalGame { get; private set; }
        public bool IsGameStarted { get; private set; }
        public float StartTimer { get; private set; }
        
        private void Awake()
        {
            networkManager = GameObject.FindGameObjectWithTag("Network")?.GetComponent<NetworkManager>();
            
            if (networkManager == null)
            {
                IsLocalGame = true;
            }
        }
        
        void Start()
        {
            InitializeGame();
            SetEvents();
            GameSetup();
        }

        private void Update()
        {
            if (networkManager != null && !IsGameOver && IsGameStarted)
            {
                int currentTime = GlobalVariables.TurnTime - (int)(Time.time - StartTimer);
                
                uiManager?.UpdateTimer(currentTime);
            }
        }

        private void InitializeGame()
        {
            IsGameOver = false;
            _turnsManager = new TurnsManager(this);
            _shipPlacer = new ShipPlacer(this);

            _turnsManager.Initialize(IsLocalGame);
        }
        
        private void SetEvents()
        {
            if (networkManager != null)
            {
                networkManager.FinishPlacing += NetworkFinishPlacing;
                networkManager.AttackReceived += NetworkAttackReceived;
                networkManager.TurnPassed += NetworkTurnPassed;
                networkManager.AttackResponse += AttackResponse;
                networkManager.OnMoveEnded += ResetTimer;
            }
            
            uiManager.ReadyButtonClicked += OnReadyButtonClicked;
            uiManager.AttackButtonClicked += OnAttackButtonClicked;
            uiManager.ResetButtonClicked += OnResetButtonClicked;
            
            _shipPlacer.AllShipsPlaced += OnAllShipsPlaced;
            
            _turnsManager.LocalPlayerTurn += OnPlayerTurn;
            _turnsManager.GameSetupFinished += OnGameSetupFinished;
        }

        private void OnGameSetupFinished()
        {
            IsGameStarted = true;
            StartGame();
        }

        private void StartGame()
        {
            _turnsManager.StartGame();
        }

        private void OnPlayerTurn(LocalPlayer localPlayer)
        {
            if (localPlayer.CanPlayTurn)
            {
                uiManager.OnPlayerTurn();
            }
            else
            {
                localPlayer.EvaluatePlayerPassingTurn();
                _turnsManager.NextTurn();
            }
        }

        public bool CanPlaceShip()
        {
            return true;
        }

        private void OnAllShipsPlaced()
        {
            uiManager.OnAllShipsPlaced();
            _turnsManager.OnAllShipsPlaced();
        }

        private void OnReadyButtonClicked()
        {
            _turnsManager.LocalPlayerIsReady();
        }

        public void GameOver(bool playerWon)
        {
            uiManager.GameOver(playerWon);
        }

        private void GameSetup()
        {
            StartCoroutine(_turnsManager.GameSetup());
        }

        public bool TryGetTile(Position position, out Tile tile)
        {
           return _turnsManager.TryGetTile(position, out tile);
        }

        public IGrid TryGetGrid()
        {
            return _turnsManager.TryGetGrid();
        }

        public void OnTileClicked(Position gridPosition)
        {
            _shipPlacer.OnTileClicked(gridPosition);
        }

        public void OnShipClicked(Ship ship)
        {
            _shipPlacer.OnShipClicked(ship);
        }

        private void OnAttackButtonClicked(Position gridPosition)
        {
            if (!_turnsManager.IsLocalPlayerTurn) return;
            
            _turnsManager.PreformAttack(gridPosition);
            _turnsManager.NextTurn();
        }

        private void OnResetButtonClicked()
        {
            _shipPlacer.ResetShipsPositions();
            _turnsManager.OnResetButtonClicked();
        }

        #region Network

        private void NetworkTurnPassed(Dictionary<string, object> data)
        {
            _turnsManager.NetworkTurnPassed(data);
        }

        private void NetworkAttackReceived(Dictionary<string, object> data)
        {
            _turnsManager.NetworkAttackReceived(data);
        }

        private void NetworkFinishPlacing(Dictionary<string, object> data)
        {
            _turnsManager.NetworkFinishPlacing(data);
            
            if (GlobalVariables.FirstTurn != GlobalVariables.UserId && IsGameStarted)
            {
                networkManager.SendMove(NetworkEvents.PassTurn , new Dictionary<string, object>());
            }
        }
        
        private void AttackResponse(Dictionary<string, object> data)
        {
            _turnsManager.AttackResponse(data);
        }
        
        private void ResetTimer()
        {
            if (IsGameStarted)
            {
                StartTimer = Time.time;
            }
        }

        #endregion
    }
}