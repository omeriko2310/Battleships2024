using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BattleShips
{
    public class UiManager : MonoBehaviour
    {
        public EndGamePopup endGamePopup;
        
        public Button readyButton;
        public Button resetButton; 
        public TMP_Text timerText;

        public Action<Position> AttackButtonClicked;
        public Action ReadyButtonClicked;
        public Action ResetButtonClicked;
        public Action ResetPlacingClicked;
        private float _startTimer;
        public bool ResetClicked { get; private set; }


        private void Start()
        {
            readyButton.interactable = false;
            endGamePopup.gameObject.SetActive(false);
        }

        public void OnReadyButtonClicked()
        {
            resetButton.interactable = false;
            
            ReadyButtonClicked.Invoke();
        }

        public void OnResetButtonClicked()
        {
            ResetClicked = true;
            
            endGamePopup.OnResetButtonClicked();
            
            ResetButtonClicked?.Invoke();
        }
        
        public void OnResetPlacing()
        {
            ResetPlayerUI();
            ResetPlacingClicked?.Invoke();
        }
        
        public void ResetGame()
        {
            ResetPlayerUI();
            ResetClicked = false;
            endGamePopup.gameObject.SetActive(false);
        }
        
        private void ResetPlayerUI()
        {
            readyButton.interactable = false;
        }

        public void OnAllShipsPlaced()
        {
            readyButton.interactable = true;
        }

        public void OnPlayerTurn()
        {
        }

        public void GameOver(bool playerWon)
        {
            endGamePopup.gameObject.SetActive(true);
            timerText.text = "0";
            
            if (playerWon)
            {
                Debug.Log("Player has won the game!");
                endGamePopup.SetWinner("Player has WON the game!");
            }
            else
            {
                Debug.Log("Player has lost the game!");
                endGamePopup.SetWinner("Player has LOST the game!");
            }
        }

        public void UpdateTimer(int currentTime)
        {
            timerText.text = currentTime > 0 ? currentTime.ToString() : "0";
        }

        public void AttackPosition(Position gridPosition)
        {
            throw new NotImplementedException();
        }
    }
}