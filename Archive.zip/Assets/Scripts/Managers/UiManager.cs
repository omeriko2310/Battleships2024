using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace BattleShips
{
    public class UiManager : MonoBehaviour
    {
        public AttackInputManager attackInputManager;
        public EndGamePrefab EndGameManager;
        
        public Button readyButton;
        public Button attackButton;
        public Button resetButton;
        public TMP_Text _timerText;

        public Action<Position> AttackButtonClicked;
        public Action ReadyButtonClicked;
        public Action ResetButtonClicked;
        private float _startTimer;


        private void Start()
        {
            readyButton.interactable = false;
            attackButton.interactable = false;
            EndGameManager.gameObject.SetActive(false);
        }

        public void OnReadyButtonClicked()
        {
            resetButton.interactable = false;
            
            ReadyButtonClicked.Invoke();
        }

        public void OnAttackButtonClicked()
        {
            var position = attackInputManager.OnAttackButtonClicked();

            attackButton.interactable = false;
            AttackButtonClicked.Invoke(position);
        }

        public void OnResetButtonClicked()
        {
            readyButton.interactable = false;
            attackButton.interactable = false;
            EndGameManager.gameObject.SetActive(false);
            
            attackInputManager.OnResetButtonClicked();
            
            ResetButtonClicked.Invoke();
        }

        public void OnAllShipsPlaced()
        {
            readyButton.interactable = true;
        }

        public void OnPlayerTurn()
        {
            attackButton.interactable = true;
            attackInputManager.OnPlayerTurn();
        }

        public void GameOver(bool playerWon)
        {
            EndGameManager.gameObject.SetActive(true);
            _timerText.text = "0";
            
            if (playerWon)
            {
                Debug.Log("Player has won the game!");
                EndGameManager.SetWinner("Player has WON the game!");
            }
            else
            {
                Debug.Log("Player has lost the game!");
                EndGameManager.SetWinner("Player has LOST the game!");
            }
        }

        public void UpdateTimer(int currentTime)
        {
            _timerText.text = currentTime > 0 ? currentTime.ToString() : "0";
        }
    }
}