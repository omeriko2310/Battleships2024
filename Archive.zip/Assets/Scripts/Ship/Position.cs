﻿using System;

namespace BattleShips
{
    [Serializable]
    public class Position
    {
        public int Row { get; private set; }
        public int Column { get; private set; }

        public Position(int row, int column)
        {
            Row = row;
            Column = column;
        }

        public override string ToString()
        {
            return $"{(char)('A' + Column)}{Row + 1}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Position other)
            {
                return Row == other.Row && Column == other.Column;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return Row * 31 + Column;
        }
        
        public static Position FromString(string coordinate)
        {
            if (string.IsNullOrEmpty(coordinate) || coordinate.Length < 2)
                return null;

            var columnChar = coordinate[0];
            var row = int.Parse(coordinate.Substring(1)) - 1;
            var column = columnChar - 'A';
            
            return new Position(row, column);
        }

        public static string ToString(Position position)
        {
            return position.ToString();
        }
    }
}