using UnityEngine;

namespace BattleShips
{
    public class ShipUI : MonoBehaviour
    {
        public Vector3 OriginalPosition { get; private set; }

        void Start()
        {
            OriginalPosition = transform.position;
        }

        public void ResetPosition()
        {
            transform.position = OriginalPosition;
        }
    }
}