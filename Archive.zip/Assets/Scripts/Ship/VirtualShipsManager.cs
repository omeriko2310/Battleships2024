﻿using UnityEngine;
using System.Collections.Generic;
using System;

namespace BattleShips
{
    public class VirtualShipsManager : ShipsManagerBase
    {
        private List<Ship> Ships = new List<Ship>();

        public VirtualShipsManager(GameManager gameManager) : base(gameManager) { }

        public override void Initialize()
        {
            // Any AI-specific initialization can be done here
        }

        public override void PlaceShips()
        {
            List<int> shipSizes = new List<int> { 4, 3, 2, 1 };

            foreach (int shipSize in shipSizes)
            {
                bool shipPlaced = false;
                int attempts = 0;

                while (!shipPlaced && attempts < 100)
                {
                    attempts++;
                    // Use UnityEngine.Random.Range directly to avoid namespace confusion
                    int row = UnityEngine.Random.Range(0, gridManager.NumRows);
                    int col = UnityEngine.Random.Range(0, gridManager.NumColumns);

                    Position startPosition = new Position(row, col);

                    if (CanPlaceShip(startPosition, shipSize))
                    {
                        // if (PlaceShip(startPosition, shipSize, ship))
                        // {
                        //     shipPlaced = true;
                        //     Ships.Add(ship); // Add the newly created ship to the Ships list
                        // }
                    }
                }

                if (!shipPlaced)
                {
                    Debug.LogError($"AI failed to place ship of size {shipSize} after {attempts} attempts.");
                    break;
                }
            }

            Debug.Log("AI has placed all ships.");
        }

        private bool CanPlaceShip(Position startPosition, int shipSize)
        {
            int row = startPosition.Row;
            int col = startPosition.Column;
            if (col + shipSize > gridManager.NumColumns) return false; // Ensure the ship can fit horizontally

            for (int i = 0; i < shipSize; i++)
            {
                Position position = new Position(row, col + i);
                if (gridManager.TryGetTile(position, out var tile) && tile.IsOccupied)
                {
                    return false; // Ship cannot be placed because a tile is already occupied
                }
            }

            return true;
        }
    }
}
