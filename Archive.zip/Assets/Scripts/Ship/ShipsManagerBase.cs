﻿using System.Collections.Generic;

namespace BattleShips
{
    public abstract class ShipsManagerBase
    {
        protected GameManager gameManager;
        protected IGrid gridManager;
        protected ShipPlacer shipPlacer;
        protected List<Ship> placedShips;

        public IGrid GridManager => gridManager;
        public List<Ship> PlacedShips => placedShips;

        protected ShipsManagerBase(GameManager gameManager)
        {
            this.gameManager = gameManager;
            placedShips = new List<Ship>();
        }

        public abstract void Initialize();
        public abstract void PlaceShips();
    }
}