﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BattleShips
{
    public class ShipPlacer
    {
        private List<Ship> _ships;
        private GameManager _gameManager;
        private IGrid _currentPlayerGrid;
        private Ship _currentShip;

        public Action AllShipsPlaced;
        
        public ShipPlacer(GameManager gameManager)
        {
            var shipObj = GameObject.FindGameObjectsWithTag("Ship");
            _ships = shipObj.Select(obj => obj.GetComponent<Ship>()).ToList();
            
            _gameManager = gameManager;
            _currentPlayerGrid = _gameManager.TryGetGrid();
        }

        public static List<Tile> PlaceShip(Position shipPlacingPosition, Ship ship, IGrid grid)
        {
            var row = shipPlacingPosition.Row;
            var col = shipPlacingPosition.Column;
            var shipSize = ship.Size;
            
            var leftmost = col - (shipSize - 1) / 2;
            var rightmost = leftmost + shipSize - 1;
            
            if (leftmost < 0)
            {
                rightmost += -leftmost;
                leftmost = 0;
            }
            
            if (rightmost > 5)
            {
                leftmost -= rightmost - 5;
                rightmost = 5;
            }
            
            if (leftmost < 0)
                return null;
            
            var shipTiles = new List<Tile>();
            
            for (var i = leftmost; i <= rightmost; i++)
            {
                var position = new Position(row, i);

                if (!grid.TryGetTile(position, out var tile) || tile.IsOccupied)
                    return null;
                
                shipTiles.Add(tile);
            }

            
            foreach (var tile in shipTiles)
            {
                tile.Occupy(ship);
            }
            
            ship.SetPositions(shipTiles);
            
            return shipTiles;
        }

        private void PlaceShipVisually(List<Tile> shipTiles, Ship ship)
        {
            var startTile = shipTiles.First();
            var endTile = shipTiles.Last();
            
            var midPointX = (startTile.transform.position.x + endTile.transform.position.x) / 2;
            var midPointY = startTile.transform.position.y;

            ship.transform.position = new Vector3(midPointX, midPointY, ship.transform.position.z);
            
            foreach (var tile in shipTiles)
            {
                tile.GetComponent<SpriteRenderer>().color = Color.green;
            }

            ship.ShipWasPlaced();
        }

        public void OnTileClicked(Position gridPosition)
        {
            if (_currentShip == null) return;
            
            var tilesPositions = PlaceShip(gridPosition, _currentShip, _currentPlayerGrid);
            
            if (tilesPositions == null) return;
            
            PlaceShipVisually(tilesPositions, _currentShip);
            
            _currentShip = null;
            
            if(CheckAllShipPlaced())
                AllShipsPlaced?.Invoke();
        }

        private bool CheckAllShipPlaced()
        {
            foreach (var ship in _ships)
            {
                if (ship.Placed == false)
                    return false;
            }

            return true;
        }

        public void OnShipClicked(Ship ship)
        {
            SpriteRenderer spriteRenderer;
            
            if (_currentShip == null)
            {
                _currentShip = ship;
                spriteRenderer = _currentShip.GetComponent<SpriteRenderer>();
                spriteRenderer.color = Color.green;
                return;
            }

            spriteRenderer = _currentShip.GetComponent<SpriteRenderer>();
            
            if (_currentShip == ship)
            {
                spriteRenderer.color = Color.white;
                _currentShip = null;
                return;
            }
            
            spriteRenderer.color = Color.white;
            
            _currentShip = ship;
            spriteRenderer = _currentShip.GetComponent<SpriteRenderer>();
            spriteRenderer.color = Color.green;
        }

        public void ResetShipsPositions()
        {
            foreach (var ship in _ships)
            {
                ship.ResetShip();
            }

            _currentPlayerGrid.ResetGrid();
        }
    }
}