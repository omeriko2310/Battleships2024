﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace BattleShips
{
    public class LocalShipsManager : ShipsManagerBase
    {
        public int totalShips = 4;
        private int shipsPlaced;
        private Ship selectedShip;
        private Dictionary<string, GameObject> unityObjects;
        private bool shipsLocked = false;
        private List<Ship> ships = new List<Ship>();

        public Button readyButton;
        public Button resetButton;

        

        public LocalShipsManager(GameManager gameManager) : base(gameManager) { }

        private void InitializeUnityObjects()
        {
            unityObjects = new Dictionary<string, GameObject>();
            GameObject[] shipObjects = GameObject.FindGameObjectsWithTag("UnityObject");
            foreach (GameObject obj in shipObjects)
            {
                if (!unityObjects.ContainsKey(obj.name))
                {
                    unityObjects.Add(obj.name, obj);
                }
            }
        }

        private void ConfigureUI()
        {
            if (readyButton != null)
            {
                readyButton.interactable = false;
                readyButton.onClick.AddListener(OnReadyButtonClick);
            }

            if (resetButton != null)
            {
                resetButton.onClick.AddListener(ResetPlacing);
            }
        }

        public void SelectShip(string shipName)
        {
            if (shipsLocked || selectedShip != null)
                return;

            if (unityObjects.TryGetValue(shipName, out GameObject shipObject))
            {
                selectedShip = shipObject.GetComponent<Ship>();
                if (selectedShip != null)
                    Debug.Log("Ship selected: " + shipName);
            }
        }

        public void PlaceSelectedShip(Position position)
        {
            if (shipsLocked || selectedShip == null)
                return;

            if (gridManager.CanPlaceShip(position, selectedShip.Size))
            {
                gridManager.PlaceShip(position, selectedShip);
                ships.Add(selectedShip);
                selectedShip = null;
                Debug.Log("Ship placed at: " + position.ToString());
                shipsPlaced++;
                if (shipsPlaced == totalShips)
                {
                    readyButton.interactable = true;
                }
            }
            else
            {
                Debug.LogError("Cannot place ship at: " + position.ToString());
            }
        }

        public override void Initialize()
        {
            // This should prepare any initialization logic specific to ship management
        }

        public override void PlaceShips()
        {
            // This method remains as a placeholder if needed for automated setup or testing
        }

        private void OnReadyButtonClick()
        {
            // LockShips();
            // gameManager.GameSetup();
        }

        private void LockShips()
        {
            // shipsLocked = true;
            // readyButton.interactable = false;
        }

        private void ResetPlacing()
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
        }

        public bool AreAllShipsPlaced()
        {
            return ships.Count == totalShips;
        }

        public bool AreAllShipsSunk()
        {
            return ships.TrueForAll(ship => ship.IsSunk);
        }
    }
}