﻿using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BattleShips
{
    public class Ship : MonoBehaviour
    {
        private GameManager _gameManger;
        public int Size;
        public bool Placed {get; private set;}
        public List<Tile> Tiles { get; private set; }
        public bool IsSunk => Tiles.TrueForAll(p => p.IsHit);
        
        private Vector3 _initialShipPosition;
        private SpriteRenderer _spriteRenderer;

        public Ship(int size)
        {
            Size = size;
        }
        
        void Start()
        {
            _gameManger = FindObjectOfType<GameManager>();
            _spriteRenderer = gameObject.GetComponent<SpriteRenderer>();
            _initialShipPosition = transform.position;
            
            Tiles ??= new List<Tile>(); // Ensure Positions is never null
        }

        public void RegisterHit(Tile hitPosition)
        {
            var tile = Tiles.FirstOrDefault(p => p.Equals(hitPosition));
            
            if (tile == null || tile == null || tile.IsHit) return;
            
            tile.IsHit = true;
            
            Debug.Log($"Ship hit at {hitPosition.GridPosition}."); // Log when a hit is registered
        }

        private void Update()
        {

        }

        void OnMouseDown()
        {
            if (Placed)
                return;
            
            _gameManger.OnShipClicked(this);
        }

        public void ShipWasPlaced()
        {
            Placed = true;
            _spriteRenderer.color = Color.white;
        }

        public void ResetShip()
        {
            Placed = false;
            
            foreach (var tile in Tiles)
            {
                tile.GetComponent<SpriteRenderer>().color = Color.white;
            }
            
            transform.position = _initialShipPosition;
            _spriteRenderer.color = Color.white;
             
            Tiles.Clear();
        }

        public void SetPositions(List<Tile> shipTiles)
        {
            Tiles = new List<Tile>(shipTiles);
        }
    }
}