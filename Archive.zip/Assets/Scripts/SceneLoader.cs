using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections;
using TMPro;

public class SceneLoader : MonoBehaviour
{
    public GameObject LoadingScreen;
    public TextMeshProUGUI loadingText;

    public void LoadScene(string sceneName)
    {
        LoadingScreen.SetActive(true);
        StartCoroutine(BeginLoad(sceneName));
    }

    IEnumerator BeginLoad(string sceneName)
    {
        LoadingScreen.SetActive(true);
        loadingText.gameObject.SetActive(true);
        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);

        asyncLoad.allowSceneActivation = false;

        while (!asyncLoad.isDone)
        {

            if (asyncLoad.progress >= 0.9f)
            {
                yield return new WaitForSeconds(0.5f);
                asyncLoad.allowSceneActivation = true;
            }

            yield return null;
        }
    }
}
