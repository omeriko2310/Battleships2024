﻿using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class AttackInputManager : MonoBehaviour
{
    public TMP_InputField attackInputField;
    public Button attackButton;
    public GameManager _gameManager;

    private void Start()
    {
        _gameManager.ReadyButtonClicked += OnReadyButtonClicked;
        attackButton.onClick.AddListener(OnAttackButtonClicked);
    }

    private void OnReadyButtonClicked()
    {
        attackButton.interactable = true;
    }

    private void OnDestroy()
    {
        attackButton.onClick.RemoveListener(OnAttackButtonClicked);
    }

    private void OnAttackButtonClicked()
    {
        string coordinate = attackInputField.text.ToUpper().Trim();

        if (IsValidCoordinate(coordinate))
        {
            Position position = Position.FromString(coordinate);

            _gameManager.ProcessPlayerAttack(position);

            attackInputField.text = ""; // Clear the input field after attack
        }
        else
        {
            Debug.LogError($"Invalid coordinate: {coordinate}");
        }
    }

    private bool IsValidCoordinate(string input)
    {
        if (string.IsNullOrEmpty(input) || input.Length < 2) return false;

        char column = input[0];
        string rowPart = input.Substring(1);

        if (column < 'A' || column > 'F') return false;

        if (!int.TryParse(rowPart, out int row)) return false;

        if (row < 1 || row > 6) return false;

        return true;
    }
}
