using UnityEngine;

public class ShipUI : MonoBehaviour
{
    public Vector3 OriginalPosition { get; private set; }

    void Start()
    {
        // Store the original position of the ship when the game starts
        OriginalPosition = transform.position;
    }

    // Optional: Add a method to reset position
    public void ResetPosition()
    {
        transform.position = OriginalPosition;
    }
}
