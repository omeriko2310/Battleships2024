﻿using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class Ship : MonoBehaviour
{
    public int Size;
    public List<Position> Positions { get; set; }
    public static event Action<string> CallShipClicked;


    public Ship(int size, List<Position> positions)
    {
        Size = size;
        Positions = positions;
    }

    void Start()
    {
        // Ensure Positions is initialized
        if (Positions == null)
            Positions = new List<Position>();
    }

    public bool IsSunk
    {
        get
        {
            // Ensure the Positions list is not null and initialized
            if (Positions == null) return false;

            // Check all positions to determine if the ship is sunk
            foreach (var position in Positions)
            {
                if (!position.IsHit) return false;
            }
            return true;
        }
    }

    public void RegisterHit(Position hitPosition)
    {
        var position = Positions.FirstOrDefault(p => p.Equals(hitPosition));
        if (position != null)
            position.IsHit = true;
    }

    void Update()
    {
        if (IsSunk)
        {
            Debug.Log("Ship has been sunk!");
            GetComponent<SpriteRenderer>().color = Color.gray; // Visual cue for debugging
        }
        else
        {
            // Log to see if positions are updating unexpectedly
            Debug.Log($"Ship not sunk. Positions hit: {Positions.Count(p => p.IsHit)}/{Positions.Count}");
        }
    }


    void OnMouseDown()
    {
        CallShipClicked?.Invoke(gameObject.name);
    }
}
