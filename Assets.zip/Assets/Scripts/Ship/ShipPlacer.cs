﻿using System.Collections.Generic;

public class ShipPlacer
{
    private IGrid grid;
    private List<Ship> ships;

    public ShipPlacer(IGrid grid, List<Ship> ships)
    {
        this.grid = grid;
        this.ships = ships;
    }

    /// Checks if a ship can be placed starting at the given position with the specified size.
    /// Assumes horizontal placement only.
    public bool CanPlaceShip(Position startPosition, int shipSize)
    {
        int row = startPosition.Row;
        int col = startPosition.Column;

        // Check if the ship fits horizontally from the starting column
        if (col + shipSize > grid.NumColumns)
            return false;

        for (int i = 0; i < shipSize; i++)
        {
            int currentCol = col + i;
            Position position = new Position(row, currentCol);

            if (grid.TryGetTile(position, out var tile))
            {
                if (tile.IsOccupied)
                    return false;
            }
            else
            {
                // Invalid tile position
                return false;
            }
        }
        return true;
    }


    /// Places a ship on the grid starting at the given position with the specified size.
    /// If a Ship object is provided, it will be used; otherwise, a new Ship is created.
    public bool PlaceShip(Position startPosition, int shipSize, Ship ship = null)
    {
        if (!CanPlaceShip(startPosition, shipSize))
            return false;

        int row = startPosition.Row;
        int col = startPosition.Column;
        List<Position> positions = new List<Position>();

        for (int i = 0; i < shipSize; i++)
        {
            int currentCol = col + i;
            Position position = new Position(row, currentCol);

            if (grid.TryGetTile(position, out var tile))
            {
                positions.Add(position);
                tile.Occupy(ship);
            }
        }

        if (ship == null)
        {
            // For AI ships that don't have a GameObject
            ship = new Ship(shipSize, positions);
        }
        else
        {
            ship.Positions = positions;
        }

        ships.Add(ship);
        return true;
    }
}
