﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class VisualShipsManager : ShipsManagerBase
{
    public int totalShips = 4;
    private int shipsPlaced = 0;
    private Ship selectedShip;
    private Dictionary<string, GameObject> unityObjects;
    private bool shipsLocked = false;
    private List<Ship> ships = new List<Ship>();

    public Button readyButton;
    public Button resetButton;

    public event Action AllShipsPlaced;

    public VisualShipsManager(GameManager gameManager, IGrid gridManager) : base(gameManager, gridManager)
    {
        InitializeUnityObjects();
        ConfigureUI();
    }

    private void InitializeUnityObjects()
    {
        unityObjects = new Dictionary<string, GameObject>();
        GameObject[] shipObjects = GameObject.FindGameObjectsWithTag("UnityObject");
        foreach (GameObject obj in shipObjects)
        {
            if (!unityObjects.ContainsKey(obj.name))
            {
                unityObjects.Add(obj.name, obj);
            }
        }
    }

    private void ConfigureUI()
    {
        if (readyButton != null)
        {
            readyButton.interactable = false;
            readyButton.onClick.AddListener(OnReadyButtonClick);
        }
        if (resetButton != null)
        {
            resetButton.onClick.AddListener(ResetPlacing);
        }
    }

    //public void TryPlaceShip(Position position, Ship ship)
    //{
    //    if (gridManager.CanPlaceShip(position, ship.Size))
    //    {
    //        gridManager.PlaceShip(position, ship);
    //        ships.Add(ship);
    //        Debug.Log("Ship placed at: " + position.ToString());
    //        if (ships.Count == totalShips)
    //        {
    //            readyButton.interactable = true;
    //            AllShipsPlaced?.Invoke();
    //        }
    //    }
    //    else
    //    {
    //        Debug.LogError("Cannot place ship at: " + position.ToString());
    //    }
    //}

    public override void Initialize()
    {
        // This should prepare any initialization logic specific to ship management
    }

    public override void PlaceShips()
    {
        // This should handle placing ships on the grid from saved states or programmatically
    }

    public void RaiseAllShipsPlacedEvent()
    {
        if (AllShipsPlaced != null)
            AllShipsPlaced.Invoke();
    }

    private void OnReadyButtonClick()
    {
        LockShips();
        gameManager.StartGame();
    }

    private void LockShips()
    {
        shipsLocked = true;
        readyButton.interactable = false;
    }

    private void ResetPlacing()
    {
        UnityEngine.SceneManagement.SceneManager.LoadScene(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name);
    }

    public bool AreAllShipsPlaced()
    {
        return ships.Count == totalShips;
    }

    public bool AreAllShipsSunk()
    {
        return ships.TrueForAll(ship => ship.IsSunk);
    }
}
