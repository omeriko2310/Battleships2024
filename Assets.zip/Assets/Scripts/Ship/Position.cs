﻿public class Position
{
    public int Row { get; private set; } 
    public int Column { get; private set; }
    public bool IsHit { get; set; }

    public Position(int row, int column)
    {
        Row = row;
        Column = column;
        IsHit = false;
    }

    public override string ToString()
    {
        return $"{(char)('A' + Column)}{Row + 1}";
    }

    public override bool Equals(object obj)
    {
        if (obj is Position other)
        {
            return Row == other.Row && Column == other.Column;
        }

        return false;
    }

    public override int GetHashCode()
    {
        return Row * 31 + Column;
    }

    private Position ConvertStringToPosition(string coordinate)
    {
        if (string.IsNullOrEmpty(coordinate) || coordinate.Length < 2)
            return null;

        char columnChar = coordinate[0];
        int row = int.Parse(coordinate.Substring(1)) - 1; // Subtract 1 because rows are zero-based
        int column = columnChar - 'A'; // Converts 'A' to 0, 'B' to 1, etc.

        return new Position(row, column);
    }

    public static Position FromString(string coordinate)
    {
        if (string.IsNullOrEmpty(coordinate) || coordinate.Length < 2)
            return null;

        char columnChar = coordinate[0];
        int row = int.Parse(coordinate.Substring(1)) - 1;
        int column = columnChar - 'A';

        return new Position(row, column);
    }

    public static string ToString(Position position)
    {
        return position.ToString();
    }
}
