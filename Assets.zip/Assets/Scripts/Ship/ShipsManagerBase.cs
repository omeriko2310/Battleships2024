﻿using System.Collections.Generic;

public abstract class ShipsManagerBase
{
    protected GameManager gameManager;
    protected IGrid gridManager;
    protected ShipPlacer shipPlacer;
    protected List<Ship> placedShips;

    public IGrid GridManager => gridManager;
    public List<Ship> PlacedShips => placedShips;

    protected ShipsManagerBase(GameManager gameManager, IGrid gridManager)
    {
        this.gameManager = gameManager;
        this.gridManager = gridManager;
        placedShips = new List<Ship>();
        shipPlacer = new ShipPlacer(gridManager, placedShips);
    }

    public abstract void Initialize();
    public abstract void PlaceShips();
}
