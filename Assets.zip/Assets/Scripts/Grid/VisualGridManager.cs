﻿using System.Collections.Generic;
using UnityEngine;

public class VisualGridManager : MonoBehaviour, IGrid
{
    public Dictionary<Position, Tile> GridTiles { get; private set; }
    public GameManager GameManagerInstance { get; set; }

    private void Awake()
    {
        GameManagerInstance = FindObjectOfType<GameManager>(); // Find and assign the GameManager instance
        InitializeGrid();
    }

    public int NumRows { get; private set; }
    public int NumColumns { get; private set; }

    public void InitializeGrid()
    {
        GridTiles = new Dictionary<Position, Tile>();

        // Check if there are tiles under the VisualGridManager
        if (transform.childCount == 0)
        {
            Debug.LogError("No tiles found under VisualGridManager. Ensure that tiles are child objects of VisualGridManager.");
            return;
        }

        for (int i = 0; i < transform.childCount; i++)
        {
            GameObject tileObject = transform.GetChild(i).gameObject;
            int row = i / GameManagerInstance.NumRows; // Now safe as GameManagerInstance is assigned
            int col = i % GameManagerInstance.NumColumns;

            Tile tileComponent = tileObject.GetComponent<Tile>();
            if (tileComponent != null)
            {
                Position position = new Position(row, col);
                tileComponent.Initialize(position);

                if (!GridTiles.ContainsKey(position))
                {
                    GridTiles.Add(position, tileComponent);
                }
                else
                {
                    Debug.LogWarning($"Duplicate tile position detected at {position}");
                }
            }
            else
            {
                Debug.LogError($"Tile component not found on child GameObject: {tileObject.name}");
            }
        }
    }



    public bool TryGetTile(Position position, out Tile tile)
    {
        return GridTiles.TryGetValue(position, out tile);
    }

    public List<Tile> GetAllTiles()
    {
        return new List<Tile>(GridTiles.Values);
    }

    public void AssignSpecialTiles(int specialTileCount)
    {
        List<Tile> allTiles = GetAllTiles();
        System.Random random = new System.Random();

        for (int i = 0; i < specialTileCount; i++)
        {
            if (allTiles.Count == 0)
            {
                Debug.LogWarning("No more tiles available to assign as special.");
                break;
            }

            int randomIndex = random.Next(allTiles.Count);
            Tile randomTile = allTiles[randomIndex];
            randomTile.MarkAsSpecial();
            allTiles.RemoveAt(randomIndex);
        }
    }
}
