﻿using System.Collections.Generic;

public interface IGrid
{
    GameManager GameManagerInstance { get; set; }
    Dictionary<Position, Tile> GridTiles { get; }
    List<Tile> GetAllTiles();
    bool TryGetTile(Position position, out Tile tile);
    void InitializeGrid();
    void AssignSpecialTiles(int specialTileCount);

    int NumRows { get; }
    int NumColumns { get; }
}
