﻿using System.Collections.Generic;
using UnityEngine;

    public class VirtualGridManager : IGrid
{
    public Dictionary<Position, Tile> GridTiles { get; private set; }
    public GameManager GameManagerInstance { get; set; }

    public int NumRows { get; private set; }
    public int NumColumns { get; private set; }

    public VirtualGridManager(GameManager gameManager, int rows, int columns)
    {
        GameManagerInstance = gameManager;
        InitializeGrid();
    }

    public void InitializeGrid()
    {
        GridTiles = new Dictionary<Position, Tile>();

        for (int row = 0; row < GameManagerInstance.NumRows; row++)
        {
            for (int col = 0; col < GameManagerInstance.NumColumns; col++)
            {
                Position position = new Position(row, col);
                Tile tile = new Tile();
                tile.Initialize(position);

                GridTiles.Add(position, tile);
            }
        }
    }

    public bool TryGetTile(Position position, out Tile tile)
    {
        return GridTiles.TryGetValue(position, out tile);
    }

    public List<Tile> GetAllTiles()
    {
        return new List<Tile>(GridTiles.Values);
    }

    public void AssignSpecialTiles(int specialTileCount)
    {
        List<Tile> allTiles = GetAllTiles();
        System.Random random = new System.Random();

        for (int i = 0; i < specialTileCount; i++)
        {
            if (allTiles.Count == 0)
            {
                Debug.LogWarning("No more tiles available to assign as special.");
                break;
            }

            int randomIndex = random.Next(allTiles.Count);
            Tile randomTile = allTiles[randomIndex];
            randomTile.MarkAsSpecial();
            allTiles.RemoveAt(randomIndex);
        }
    }
}
