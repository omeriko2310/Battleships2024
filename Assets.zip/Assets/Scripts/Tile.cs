using System;
using UnityEngine;

public class Tile : MonoBehaviour
{
    public bool IsOccupied { get; private set; }
    public Ship OccupyingShip { get; private set; }
    public Position GridPosition { get; private set; }
    public bool IsSpecialTile { get; private set; }
    public bool IsHit { get; private set; }

    public static event Action<Position> CallTileClicked;

    private SpriteRenderer _spriteRenderer;

    void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    public void Initialize(Position position)
    {
        GridPosition = position;
    }

    public void Occupy(Ship ship)
    {
        IsOccupied = true;
        OccupyingShip = ship;
    }

    public void Clear()
    {
        IsOccupied = false;
        OccupyingShip = null;
        HighlightTile(false);
    }

    public void HighlightTile(Color color)
    {
        _spriteRenderer.color = color;
    }


    public void HighlightTile(bool isSelected)
    {
        _spriteRenderer.color = isSelected ? Color.green : Color.white;
    }

    public void MarkAsSpecial()
    {
        IsSpecialTile = true;
    }


    public void MarkAsHit()
    {
        if (GridPosition.IsHit)
            return; // Already hit

        GridPosition.IsHit = true;

        if (IsOccupied)
        {
            OccupyingShip.RegisterHit(GridPosition);
            HighlightTile(Color.red);
        }
        else
        {
            HighlightTile(Color.blue);
        }
    }

    void OnMouseDown()
    {
        if (IsSpecialTile)
        {
            Debug.Log($"Tile {GridPosition} is a special tile! Turn lost.");
            return;
        }

        if (!GridPosition.IsHit)
        {
            // Handle tile click event
            CallTileClicked?.Invoke(GridPosition);
        }
    }
}
