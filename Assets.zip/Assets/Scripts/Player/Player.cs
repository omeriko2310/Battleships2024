﻿using System.Collections;
using System.Collections.Generic;

public abstract class Player
{
    public IGrid GridManager { get; protected set; }
    public GameManager GameManagerInstance { get; set; }
    public ShipsManagerBase ShipsManagerInstance { get; protected set; }

    public abstract void Initialize();
    public abstract void PerformAttack(Player opponent);
    public abstract void ReceiveAttack(Position position);
    public abstract IEnumerator ProcessTurnAsync(Player opponent);

    protected Player(GameManager gameManager, ShipsManagerBase shipsManager, IGrid gridManager)
    {
        GameManagerInstance = gameManager;
        ShipsManagerInstance = shipsManager;
        GridManager = gridManager;
    }

    public List<Ship> GetShips()
    {
        return ShipsManagerInstance.PlacedShips;
    }

    public bool AreAllShipsSunk()
    {
        return ShipsManagerInstance.PlacedShips.TrueForAll(ship => ship.IsSunk);
    }
}
