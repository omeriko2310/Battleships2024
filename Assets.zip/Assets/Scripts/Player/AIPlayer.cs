﻿using UnityEngine;
using System.Collections.Generic;
using System.Collections;

public class AIPlayer : Player
{
    public AIPlayer(GameManager gameManager, ShipsManagerBase shipsManager, IGrid gridManager)
        : base(gameManager, shipsManager, gridManager) { }

    public override void Initialize()
    {
        GridManager = new VirtualGridManager(GameManagerInstance, 6, 6);
        PlaceShipsRandomlyOnGrid();
    }

    public override void PerformAttack(Player opponent)
    {
        Position attackPosition = GenerateRandomAttackPosition(opponent.GridManager);
        opponent.ReceiveAttack(attackPosition);
        Debug.Log($"AI attacks position {attackPosition}");
    }

    public override IEnumerator ProcessTurnAsync(Player opponent)
    {
        // Simulate AI thinking time
        yield return new WaitForSeconds(1f);

        // AI performs attack
        PerformAttack(opponent);
    }

    public override void ReceiveAttack(Position position)
    {
        if (GridManager.TryGetTile(position, out var tile))
        {
            if (tile.GridPosition.IsHit)
            {
                Debug.Log($"Tile {position} has already been attacked.");
                return;
            }

            tile.MarkAsHit();

            if (tile.IsOccupied)
            {
                var ship = tile.OccupyingShip;
                ship?.RegisterHit(position);
                Debug.Log($"You hit AI's ship at {position}!");

                if (ship.IsSunk)
                {
                    Debug.Log($"AI's ship of size {ship.Size} has been sunk!");
                }
            }
            else
            {
                Debug.Log($"You missed at {position}.");
            }
        }
        else
        {
            Debug.LogError($"Invalid tile at position: {position}");
        }
    }

    private Position GenerateRandomAttackPosition(IGrid opponentGrid)
    {
        int numRows = GameManagerInstance.NumRows;
        int numColumns = GameManagerInstance.NumColumns;
        var gridTiles = opponentGrid.GridTiles;

        Position position;
        do
        {
            int row = Random.Range(0, numRows);
            int column = Random.Range(0, numColumns);
            position = new Position(row, column);
        }
        while (gridTiles[position].GridPosition.IsHit);

        return position;
    }

    private void PlaceShipsRandomlyOnGrid()
    {
        ShipPlacer shipPlacer = new ShipPlacer(GridManager, ShipsManagerInstance.PlacedShips);
        List<int> shipSizes = new List<int> { 4, 3, 2, 1 };

        foreach (int shipSize in shipSizes)
        {
            bool shipPlaced = false;
            int attempts = 0;

            while (!shipPlaced && attempts < 100)
            {
                attempts++;
                int row = Random.Range(0, GridManager.GameManagerInstance.NumRows);
                int col = Random.Range(0, GridManager.GameManagerInstance.NumColumns);

                Position startPosition = new Position(row, col);

                if (shipPlacer.CanPlaceShip(startPosition, shipSize))
                {
                    shipPlacer.PlaceShip(startPosition, shipSize);
                    shipPlaced = true;
                }
            }

            if (!shipPlaced)
            {
                Debug.LogError($"AI failed to place ship of size {shipSize} after {attempts} attempts.");
                break;
            }
        }

        Debug.Log("AI has placed all ships.");
    }

}
