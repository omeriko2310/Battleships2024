﻿using System.Collections;
using UnityEngine;

public class LocalPlayer : Player
{
    public LocalPlayer(GameManager gameManager, ShipsManagerBase shipsManager, IGrid gridManager)
    : base(gameManager, shipsManager, gridManager) { }

    public override void Initialize()
    {
        ShipsManagerInstance.Initialize();
    }

    public override void PerformAttack(Player opponent)
    {
        // Attack logic is driven by user input elsewhere
    }

    public override IEnumerator ProcessTurnAsync(Player opponent)
    {
        // The local player's turn is driven by user input elsewhere
        yield return null;
    }

    public override void ReceiveAttack(Position position)
    {
        if (GridManager.TryGetTile(position, out var tile))
        {
            if (tile.GridPosition.IsHit)
            {
                Debug.Log($"Tile {position} has already been attacked.");
                return;
            }

            tile.MarkAsHit();

            if (tile.IsOccupied)
            {
                var ship = tile.OccupyingShip;
                ship?.RegisterHit(position);
                Debug.Log($"Your ship was hit at {position}!");

                if (ship.IsSunk)
                {
                    Debug.Log($"Your ship of size {ship.Size} has been sunk!");
                }
            }
            else
            {
                Debug.Log($"Enemy missed at {position}.");
            }
        }
        else
        {
            Debug.LogError($"Invalid tile at position: {position}");
        }
    }
}
