using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OpenLink : MonoBehaviour
{
    void Start()
    {
        
    }

    public void OpenLinkedIn()
    {
        Application.OpenURL("https://www.linkedin.com/in/omer-ben-israel-3890a0234/");
    }
}
