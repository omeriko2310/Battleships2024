using System;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public int NumColumns = 6;
    public int NumRows = 6;

    public VisualShipsManager visualShipsManager; // Responsible for managing ship placement on visual grid
    public TurnsManager turnsManager; // Manages the turns of players
    public VirtualShipsManager virtualShipsManager;

    public VisualGridManager visualGridManager;
    public VirtualGridManager virtualGridManager;

    private Player _localPlayer;
    private Player _opponentPlayer;

    public Action ReadyButtonClicked { get; set; }

    void Start()
    {
        visualShipsManager.AllShipsPlaced += visualShipsManager.RaiseAllShipsPlacedEvent;
        visualShipsManager.Initialize();
    }


    //public void OnReadyButtonClicked()
    //{
    //    if (visualShipsManager.AllShipsPlaced())
    //    {
    //        StartGame();
    //    }
    //    else
    //    {
    //        Debug.Log("All ships are not properly placed.");
    //    }
    //}

    public void InitializeGame()
    {
        // Determine the opponent type (AI or remote player)
        _localPlayer = new LocalPlayer(this, visualShipsManager, visualGridManager);
        _opponentPlayer = new AIPlayer(this, virtualShipsManager, virtualGridManager);

        _localPlayer.Initialize();
        _opponentPlayer.Initialize();

        turnsManager.Initialize(this);

        visualGridManager = GameObject.FindGameObjectWithTag("GridManager").GetComponent<VisualGridManager>();
        visualShipsManager.AllShipsPlaced += OnAllShipsPlaced;
    }

    private void OnAllShipsPlaced()
    {
        visualGridManager.AssignSpecialTiles(5);

        ReadyButtonClicked.Invoke();
    }

    public Player GetLocalPlayer()
    {
        return _localPlayer;
    }

    public Player GetOpponentPlayer()
    {
        return _opponentPlayer;
    }

    public void GameOver(bool playerWon)
    {
        if (playerWon)
        {
            Debug.Log("Player has won the game!");
        }
        else
        {
            Debug.Log("Player has lost the game!");
        }

        // Additional game over handling
    }

    internal void ProcessPlayerAttack(Position position)
    {
        turnsManager.ProcessPlayerAttack(position);
    }

    internal void StartGame()
    {
        turnsManager.StartGame();
    }

    internal bool TryGetTile(Position position, out Tile tile)
    {
        return visualGridManager.TryGetTile(position,out tile);
    }
}
