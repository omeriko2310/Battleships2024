﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class GridManager : MonoBehaviour
{
    public int NumRows = 6;
    public int NumColumns = 6;

    public Dictionary<Position, Tile> GridTiles;

    private void Awake()
    {
        InitializeGrid();
    }

    private void InitializeGrid()
    {
        GridTiles = new Dictionary<Position, Tile>();

        // Check if there are tiles under the GridManager
        if (transform.childCount == 0)
        {
            Debug.LogError("No tiles found under GridManager. Ensure that tiles are child objects of GridManager.");
            return;
        }

        for (int i = 0; i < transform.childCount; i++)
        {
            GameObject tileObject = transform.GetChild(i).gameObject;
            int row = i / NumColumns;
            int col = i % NumColumns;

            Tile tileComponent = tileObject.GetComponent<Tile>();
            if (tileComponent != null)
            {
                Position position = new Position(row, col);
                tileComponent.Initialize(position);

                if (!GridTiles.ContainsKey(position))
                {
                    GridTiles.Add(position, tileComponent);
                }
                else
                {
                    Debug.LogWarning($"Duplicate tile position detected at {position}");
                }
            }
            else
            {
                Debug.LogError($"Tile component not found on child GameObject: {tileObject.name}");
            }
        }
    }

    public bool TryGetTile(Position position, out Tile tile)
    {
        return GridTiles.TryGetValue(position, out tile);
    }

    public List<Tile> GetAllTiles()
    {
        return new List<Tile>(GridTiles.Values);
    }

    public void AssignSpecialTiles(int specialTileCount)
    {
        List<Tile> allTiles = GetAllTiles();
        System.Random random = new System.Random();

        for (int i = 0; i < specialTileCount; i++)
        {
            if (allTiles.Count == 0)
            {
                Debug.LogWarning("No more tiles available to assign as special.");
                break;
            }

            int randomIndex = random.Next(allTiles.Count);
            Tile randomTile = allTiles[randomIndex];
            randomTile.MarkAsSpecial();
            allTiles.RemoveAt(randomIndex);
        }
    }

    public void InitializeVirtualGrid()
    {

    }

    public static implicit operator GridManager(VirtualGridManager v)
    {
        throw new NotImplementedException();
    }
}
