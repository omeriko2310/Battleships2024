﻿using UnityEngine;
using System.Collections;
using System;

public class TurnsManager : MonoBehaviour
{
    private GameManager _gameManager;
    private bool _isLocalPlayerTurn;

    internal void Initialize(GameManager gameManager)
    {
        _gameManager = gameManager;


        StartGame();
    }

    public void StartGame()
    {
        _isLocalPlayerTurn = true;
        Debug.Log("Game started. Local player's turn.");
    }

    public void ProcessPlayerAttack(Position position)
    {
        if (!_isLocalPlayerTurn)
        {
            Debug.LogWarning("It's not the local player's turn.");
            return;
        }

        // Local player performs attack
        _gameManager.GetLocalPlayer().PerformAttack(_gameManager.GetOpponentPlayer());

        if (_gameManager.GetOpponentPlayer().AreAllShipsSunk())
        {
            Debug.Log("Local player wins!");
            _gameManager.GameOver(true);
        }
        else
        {
            _isLocalPlayerTurn = false;
            StartCoroutine(ProcessOpponentTurn());
        }
    }

    private IEnumerator ProcessOpponentTurn()
    {
        yield return _gameManager.GetOpponentPlayer().ProcessTurnAsync(_gameManager.GetLocalPlayer());

        if (_gameManager.GetLocalPlayer().AreAllShipsSunk())
        {
            Debug.Log("Opponent wins!");
            _gameManager.GameOver(false);
        }
        else
        {
            _isLocalPlayerTurn = true;
            Debug.Log("Local player's turn.");
        }
    }
}
