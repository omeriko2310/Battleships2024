//using System;
//using System.Collections;
//using System.Collections.Generic;
//using AssemblyCSharp;
//using com.shephertz.app42.gaming.multiplayer.client;
//using UnityEngine;

//public class NetworkManager: MonoBehaviour
//{
//    private string apiKey = "954032240a8d5898bce2acfc912d541eebb0a72954ba0b61f74dc793001174bf";
//    private string secretKey = "0dea4cfbbbbced3d359ebc875f0444df53da14ba2c3146c03f68681aeed29e26";

//    private Listener myListener;
//    private string userId = string.Empty;


//    private void OnEnable()
//    {
//        Listener.OnConnect += OnConnect;
//    }


//    private void OnDisable()
//    {
//        Listener.OnConnect -= OnConnect;
//    }


//    private void Awake()
//    {
//        if (myListener == null)
//             myListener = new Listener();

//        WarpClient.initialize(apiKey, secretKey); //save my api and secret keys
//        WarpClient.GetInstance().AddChatRequestListener(myListener);
//        WarpClient.GetInstance().AddConnectionRequestListener(myListener);
//        WarpClient.GetInstance().AddUpdateRequestListener(myListener);
//        WarpClient.GetInstance().AddLobbyRequestListener(myListener);
//        WarpClient.GetInstance().AddNotificationListener(myListener);
//        WarpClient.GetInstance().AddRoomRequestListener(myListener);
//        WarpClient.GetInstance().AddZoneRequestListener(myListener);
//        WarpClient.GetInstance().AddTurnBasedRoomRequestListener(myListener);


//        userId = System.Guid.NewGuid().ToString();
//        WarpClient.GetInstance().Connect(userId);
//        Debug.Log("Connecting...");
//    }

//    void Start()
//    {
        
//    }


//    void Update()
//    {
        
//    }


//    private void OnConnect(bool _IsSuccess)
//    {
//        Debug.Log("OnConnect" + _IsSuccess);
//    }

//}
